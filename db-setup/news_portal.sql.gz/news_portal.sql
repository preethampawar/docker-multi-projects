-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Generation Time: Nov 11, 2025 at 01:11 PM
-- Server version: 8.0.44
-- PHP Version: 8.3.27

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news_portal`
--
CREATE DATABASE IF NOT EXISTS `news_portal` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `news_portal`;

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `blog_category_id` bigint UNSIGNED DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','published') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blogs_slug_unique` (`slug`),
  KEY `blogs_user_id_foreign` (`user_id`),
  KEY `blogs_blog_category_id_foreign` (`blog_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

DROP TABLE IF EXISTS `blog_categories`;
CREATE TABLE IF NOT EXISTS `blog_categories` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blog_categories_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_tag`
--

DROP TABLE IF EXISTS `blog_tag`;
CREATE TABLE IF NOT EXISTS `blog_tag` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `blog_id` bigint UNSIGNED NOT NULL,
  `tag_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_tag_blog_id_foreign` (`blog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE IF NOT EXISTS `job_batches` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_09_10_063333_add_is_admin_to_users_table', 1),
(5, '2025_09_10_075810_create_blog_categories_table', 2),
(6, '2025_09_10_075810_create_news_categories_table', 2),
(7, '2025_09_10_075811_create_news_table', 2),
(8, '2025_09_10_075812_create_blogs_table', 2),
(9, '2025_09_13_070341_add_views_to_news_table', 3),
(10, '2025_09_13_072130_add_active_to_news_categories_table', 4),
(11, '2025_09_13_073024_add_priority_to_news_categories_table', 5),
(12, '2025_09_14_093727_add_likes_to_news_table', 6),
(13, '2025_09_14_094833_create_news_likes_table', 7),
(14, '2025_09_14_103341_add_is_featured_to_news_table', 8),
(15, '2025_09_14_112229_add_show_in_nav_to_news_categories_table', 9),
(16, '2025_09_20_031858_create_tags_table', 10),
(17, '2025_09_27_163111_add_has_video_to_news_table', 11),
(18, '2025_09_20_031858_create_blog_tag_table', 12),
(19, '2025_09_20_031858_create_news_tag_table', 12);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `news_category_id` bigint UNSIGNED DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','published') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `has_video` tinyint(1) NOT NULL DEFAULT '0',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `views` bigint UNSIGNED NOT NULL DEFAULT '0',
  `likes` bigint UNSIGNED NOT NULL DEFAULT '0',
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `news_slug_unique` (`slug`),
  KEY `news_user_id_foreign` (`user_id`),
  KEY `news_news_category_id_foreign` (`news_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `user_id`, `news_category_id`, `title`, `slug`, `excerpt`, `content`, `image`, `status`, `has_video`, `is_featured`, `views`, `likes`, `published_at`, `created_at`, `updated_at`) VALUES
(1, 5, 1, 'Putin and Modi - page title', 'article-1', 'Finally! Putin and Modi Article 1 is out', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>', 'VmKVgV8WgQv6Dpg0vrQzmUhuuDUhw7aaMkLDBZpO.webp', 'published', 1, 1, 303, 0, '2025-09-10 13:19:00', '2025-09-10 07:49:09', '2025-09-27 11:17:09'),
(2, 5, 2, 'Article 2', 'article-2', 'Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit', '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', 'lF33sDR5Cr6ZRciBxebMhSoxpqeA4o7ab3fzS1dq.png', 'published', 1, 0, 5, 0, '2025-09-09 13:31:00', '2025-09-10 08:02:28', '2025-09-27 11:17:18'),
(3, 5, 2, 'Article 3', 'article-3', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.', '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', 'FCaGF0hdWPHBhzNqtFhhRTIyGH0bLjIsWii89Cqf.jpg', 'published', 1, 1, 300, 0, '2025-09-08 13:33:00', '2025-09-10 08:03:23', '2025-09-27 12:17:07'),
(4, 5, 2, 'Article 4', 'article-4', 'The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters', 'The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', 'Tdv4jwsdRgql5b0JdGDLs5oYkheivDMb2wxVny2g.png', 'published', 0, 0, 0, 0, '2025-09-07 13:34:00', '2025-09-10 08:04:40', '2025-09-27 09:03:23'),
(5, 5, 2, 'Article 5', 'article-5', 'Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', 'The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', '2gN72Zulvmd5SfZhljOQbYm3HqjH4I6mXpo2QxPS.png', 'published', 0, 0, 8, 0, '2025-09-09 13:35:00', '2025-09-10 08:05:11', '2025-09-27 09:03:23'),
(6, 5, 2, 'Article 6', 'article-6', 'Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy.', '<p><strong>The point of using Lorem Ipsum is that it has a more-or-less no</strong>rmal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English.&nbsp;</p><ul><li><p>Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy.&nbsp;</p><figure class=\"image\"><img style=\"aspect-ratio:321/327;\" src=\"http://127.0.0.1:8000/storage/ckeditor/cEgzzDY4JpnvCwyW13Jj9GrNRAnuxdM5q02JKUVk.jpg\" width=\"321\" height=\"327\"></figure></li><li>Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</li><li><figure class=\"media\"><div data-oembed-url=\"https://www.youtube.com/watch?v=wyQX8agtaI0\"><div style=\"position: relative; padding-bottom: 100%; height: 0; padding-bottom: 56.2493%;\"><iframe src=\"https://www.youtube.com/embed/wyQX8agtaI0\" style=\"position: absolute; width: 100%; height: 100%; top: 0; left: 0;\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen=\"\"></iframe></div></div></figure></li></ul>', '0HsZ6lbJjXB9V6vimTAo28PZpFfRsBqB8kIFKp3j.png', 'published', 1, 0, 29, 0, '2025-09-10 13:36:00', '2025-09-10 08:06:13', '2025-09-27 12:17:39'),
(7, 5, 2, 'Article 7', 'article-4-ujA5GB', 'The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters', 'The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', 'Tdv4jwsdRgql5b0JdGDLs5oYkheivDMb2wxVny2g.png', 'published', 0, 0, 3, 0, '2025-09-09 15:41:00', '2025-09-10 08:11:23', '2025-09-27 09:03:24'),
(8, 5, 2, 'Article 8', 'article-4-58kOM0', 'The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters', '<p>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>', 'Tdv4jwsdRgql5b0JdGDLs5oYkheivDMb2wxVny2g.png', 'published', 1, 0, 1, 0, '2025-09-04 13:42:00', '2025-09-10 08:12:40', '2025-09-27 12:16:39'),
(9, 5, 3, 'King Cobra Attack:  అమ్మో  అరుదైన కింగ్ కోబ్రా.. చూస్తేనే ఒళ్ళు జలదరిస్తుంది', 'king-cobra-attack', 'King Cobra Attack:  అమ్మో  అరుదైన కింగ్ కోబ్రా.. చూస్తేనే ఒళ్ళు జలదరిస్తుంది', '<p>సాధారణంగా కొందరికి పాములను చూడగానే ఆమడ దూరం పరుగెడతారు. కొందరు దైర్యం చేసి దూరం నుంచే పామును చూస్తుంటారు. మరికొందరు ఏకంగా పామును పట్టుకుంటారు. కింగ్ కోబ్రా నల్లగా పొడవుగా ఉంటుంది. మామూలు పాములను ,నాగు, తాచు పాములను తింటుంటుంది. దీని నోరు కూడా పెద్దగానే ఉంటుంది. స్పీడ్ గా కదులుతుంది.</p><p>సాధారణంగా దట్టమైన ఆఫ్రికా అడవుల్లో వీటి సంచారం ఎక్కువగా ఉంటుంది. మనదేశంలో.. కూడా వీటి సంచారం ఎక్కువగానే ఉంటుంది. అయితే.. ఆంధ్రప్రదేశ్ రాష్ట్రంలో చాలా చోట్ల కనిపిస్తుంటాయి.. ఆంధ్రా ఒరిస్సా సరిహద్దు ప్రాంతాలు, అల్లూరి సీతారామరాజు, విశాఖ, మన్యం జిల్లాల్లో ఎక్కువగా కనిపిస్తుంటాయి.. ఇవి కరిస్తే.. బతకడం మాత్రమే కష్టమే అంటున్నారు నిఫుణులు.&nbsp;</p><p>రంగంలోకి దిగిన స్నేక్ క్యాచర్ కింగ్ కోబ్రాను వెంబడించి ఎంతో చాకచక్యంగా దానిని బంధించాడు.. కింగ్ కోబ్రాను పట్టుకొనే క్రమంలో అది బుసలు కొడుతూ రగిలిపోయింది. స్నేక్ క్యాచర్ దాని దృష్టి మళ్లించేందుకు చెప్పును చూపిస్తూ అటూ ఇటూ ఆడించగా ఒక్కసారిగా నోటితో చెప్పును అందుకొని కరచింది. పొరపాటున అది చెప్పును కాకుండా.. స్నేక్ క్యాచర్ ని కాటేసి ఉంటే.. ఊహించడానికే భయంగా ఉంది. అనంతరం దాని నోటి నుండి చెప్పును బయటకు తీసి.. కింగ్ కోబ్రాను దూరంగా అటవీ ప్రాంతంలో వదిలేశాడు.</p><p>&nbsp;</p>', 'xtdqg2J9HV4STAY89I2oDK1xKGcH4Wc5FAA5PpLu.webp', 'published', 1, 1, 189, 0, '2025-09-19 00:33:00', '2025-09-13 08:05:00', '2025-11-09 17:58:53'),
(11, 5, 1, 'అరుదైన', 'education-news', 'eee', '<p>dd</p>', 'c5818ebc-8a82-467d-926d-e6eab2fe6d70.png', 'draft', 1, 0, 0, 0, '2025-09-26 15:05:00', '2025-09-26 15:31:59', '2025-09-27 12:16:21');

-- --------------------------------------------------------

--
-- Table structure for table `news_categories`
--

DROP TABLE IF EXISTS `news_categories`;
CREATE TABLE IF NOT EXISTS `news_categories` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `active` tinyint UNSIGNED NOT NULL DEFAULT '1',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `priority` smallint DEFAULT '0',
  `show_in_nav` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `news_categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news_categories`
--

INSERT INTO `news_categories` (`id`, `active`, `name`, `slug`, `description`, `priority`, `show_in_nav`, `created_at`, `updated_at`) VALUES
(1, 1, 'Politics', 'politics', 'All news article related to politics go here', 2, 1, '2025-09-10 07:47:33', '2025-09-26 13:20:23'),
(2, 1, 'India', 'india', 'all news related to India go here', 3, 1, '2025-09-10 07:47:52', '2025-09-26 13:20:28'),
(3, 1, 'Zaheerabad', 'zhb', 'News related to Zaheerabad', 1, 1, '2025-09-13 07:59:58', '2025-09-26 13:54:05'),
(4, 1, 'SSSS', 'SS', NULL, NULL, 0, '2025-09-26 14:00:53', '2025-09-26 14:02:44'),
(5, 1, 'eeee', 'eee', NULL, NULL, 0, '2025-09-26 14:01:01', '2025-09-26 14:02:57'),
(6, 1, 'rrr', 'rrr', NULL, NULL, 0, '2025-09-26 14:01:23', '2025-09-26 14:02:51');

-- --------------------------------------------------------

--
-- Table structure for table `news_likes`
--

DROP TABLE IF EXISTS `news_likes`;
CREATE TABLE IF NOT EXISTS `news_likes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `news_id` bigint UNSIGNED NOT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `news_likes_news_id_ip_address_unique` (`news_id`,`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news_likes`
--

INSERT INTO `news_likes` (`id`, `news_id`, `ip_address`, `created_at`, `updated_at`) VALUES
(5, 5, '127.0.0.1', '2025-09-14 09:06:42', '2025-09-14 09:06:42'),
(12, 4, '127.0.0.1', '2025-09-18 03:46:12', '2025-09-18 03:46:12'),
(17, 9, '127.0.0.1', '2025-09-18 04:04:00', '2025-09-18 04:04:00'),
(19, 1, '127.0.0.1', '2025-09-18 07:08:52', '2025-09-18 07:08:52');

-- --------------------------------------------------------

--
-- Table structure for table `news_tag`
--

DROP TABLE IF EXISTS `news_tag`;
CREATE TABLE IF NOT EXISTS `news_tag` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `news_id` bigint UNSIGNED NOT NULL,
  `tag_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `news_tag_news_id_foreign` (`news_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `news_tag`
--

INSERT INTO `news_tag` (`id`, `news_id`, `tag_id`, `created_at`, `updated_at`) VALUES
(5, 9, 8, NULL, NULL),
(6, 9, 9, NULL, NULL),
(7, 8, 9, NULL, NULL),
(10, 1, 2, NULL, NULL),
(11, 1, 4, NULL, NULL),
(12, 1, 6, NULL, NULL),
(13, 1, 9, NULL, NULL),
(14, 1, 7, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('EvlKlkLopOMqLsN4WvJuFk9UT8N1Kn5ozN821GkJ', 5, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:143.0) Gecko/20100101 Firefox/143.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiSE5JMjJhbVg4UTlaUTV0OFpkaHVpVkNNT1ZPU3ZCNnZBakZ3NTZNdCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjU7fQ==', 1759003084),
('fW5MwqmOVyONi9ffWBzUJpw041YwcYIYn8TIWCvq', NULL, '192.168.65.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY0p3eEduRkZBaElXWkRwaUI0cXFuVGpRZHhqVXlBUXFuNUo3dTMyYyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHA6Ly93d3cuZ3JhbWF2YW5pLmxjL25ld3MvY2F0ZWdvcnkvemhiIjtzOjU6InJvdXRlIjtzOjE1OiJuZXdzLmJ5Q2F0ZWdvcnkiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1762711157),
('rCm4JsMUfdSPIJ28SpMTZJzSBMBNzEkn79JjIdEe', NULL, '192.168.65.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRHJEa3hEckFSdG5tNkIxbzQxUWRTYVBNQXpFVDJGdnJBZWY0c2NEMSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHA6Ly93d3cuZ3JhbWF2YW5pLmxjIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1762774594);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_name_unique` (`name`),
  UNIQUE KEY `tags_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'test', 'test', '2025-09-20 00:34:52', '2025-09-20 00:34:52'),
(2, 'why', 'why', '2025-09-20 00:35:01', '2025-09-20 00:35:01'),
(3, 'temp', 'temp', '2025-09-20 00:35:15', '2025-09-20 00:35:15'),
(4, 'right', 'right', '2025-09-20 00:35:21', '2025-09-20 00:35:21'),
(5, 'blank', 'blank', '2025-09-20 00:37:16', '2025-09-20 00:37:16'),
(6, 'blink', 'blink', '2025-09-20 00:39:01', '2025-09-20 00:39:01'),
(7, 'blogs', 'blogs', '2025-09-20 00:40:40', '2025-09-20 00:40:40'),
(8, 'Snakes', 'snakes', '2025-09-20 05:54:56', '2025-09-20 05:54:56'),
(9, 'King Cobra', 'king-cobra', '2025-09-20 05:55:08', '2025-09-20 05:55:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `is_admin`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(4, 'Test User', 'test@example.com', 0, '2025-09-10 01:22:07', '$2y$12$7LiEQbmjjbNdxMmjQqBelOFsnhHL7.s5I3cb1zygWJcbfEz2BX48G', '', '2025-09-10 01:22:07', '2025-09-10 01:22:07'),
(5, 'Admin', 'admin@localhost.com', 1, '2025-09-10 01:22:07', '$2y$12$HfpgiE.egDIyoMdMDYAyXe4tKo8rw5uQaBKStHIXivbhIFFFTgGri', '', '2025-09-10 01:22:07', '2025-09-10 01:22:07');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blogs`
--
ALTER TABLE `blogs`
  ADD CONSTRAINT `blogs_blog_category_id_foreign` FOREIGN KEY (`blog_category_id`) REFERENCES `blog_categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `blogs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `blog_tag`
--
ALTER TABLE `blog_tag`
  ADD CONSTRAINT `blog_tag_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `news`
--
ALTER TABLE `news`
  ADD CONSTRAINT `news_news_category_id_foreign` FOREIGN KEY (`news_category_id`) REFERENCES `news_categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `news_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `news_likes`
--
ALTER TABLE `news_likes`
  ADD CONSTRAINT `news_likes_news_id_foreign` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `news_tag`
--
ALTER TABLE `news_tag`
  ADD CONSTRAINT `news_tag_news_id_foreign` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
