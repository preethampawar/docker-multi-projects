-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Generation Time: Nov 11, 2025 at 01:08 PM
-- Server version: 8.0.44
-- PHP Version: 8.3.27

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `winesapp_v3`
--
CREATE DATABASE IF NOT EXISTS `winesapp_v3` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `winesapp_v3`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `datewise_product_stock_report`$$
CREATE DEFINER=`root`@`%` PROCEDURE `datewise_product_stock_report` (IN `storeId` INT, IN `fromDate` DATE, IN `toDate` DATE)   BEGIN
	
	   SELECT 
	    `p`.`id` AS `product_id`,
	    `p`.`product_name` AS `product_name`,
	    `p`.`brand_id`,
	    `p`.`unit_selling_price` AS `unit_selling_price`,
	    `p`.`box_buying_price` AS `box_buying_price`,
	    `p`.`box_qty` AS `box_qty`,
	    `br`.`name` AS `brand_name`,
	    `c`.`id` AS `category_id`,
	    `c`.`name` AS `category_name`,
	    `p`.`store_id` AS `store_id`,
	    COALESCE(`p`.`purchase_qty`, 0) AS `purchase_qty`,
	    COALESCE(`p`.`purchase_amount`, 0) AS `purchase_amount`,
	    COALESCE(`s`.`sale_qty`, 0) AS `sale_qty`,
	    COALESCE(`s`.`sale_amount`, 0) AS `sale_amount`,
	    COALESCE(`b`.`breakage_qty`, 0) AS `breakage_qty`,
	    COALESCE(`b`.`breakage_amount`, 0) AS `breakage_amount`,
		COALESCE(`sto`.`stock_transfer_out_qty`, 0) AS `stock_transfer_out_qty`,
	    COALESCE(`sto`.`stock_transfer_out_amount`, 0) AS `stock_transfer_out_amount`,
	    COALESCE(`sti`.`stock_transfer_in_qty`, 0) AS `stock_transfer_in_qty`,
	    COALESCE(`sti`.`stock_transfer_in_amount`, 0) AS `stock_transfer_in_amount`,
	    (
	      COALESCE(`p`.`purchase_qty`, 0) 
	      + COALESCE(`sti`.`stock_transfer_in_qty`, 0) 
	      - COALESCE(`s`.`sale_qty`, 0) 
	      - COALESCE(`b`.`breakage_qty`, 0) 
	      - COALESCE(`sto`.`stock_transfer_out_qty`, 0)
	    ) AS `balance_qty`,
	    (
	      COALESCE(`s`.`sale_amount`, 0) 
	      + COALESCE(`sto`.`stock_transfer_out_amount`, 0) 
	      - COALESCE(`p`.`purchase_amount`, 0) 
	      - COALESCE(`b`.`breakage_qty`, 0)
	      - COALESCE(`sti`.`stock_transfer_in_amount`, 0) 
	    ) AS `profit_amount` 
	  FROM
	    (SELECT 
	      `pr`.`id` AS `id`,
	      `pr`.`name` AS `product_name`,
	      `pr`.`brand_id` AS `brand_id`,
	      `pr`.`unit_selling_price` AS `unit_selling_price`,
	      `pr`.`box_buying_price` AS `box_buying_price`,
	      `pr`.`box_qty` AS `box_qty`,
	      `pr`.`product_category_id` AS `product_category_id`,
	      `pr`.`store_id` AS `store_id`,
	      COALESCE(SUM(`pu`.`total_units`), 0) AS `purchase_qty`,
	      COALESCE(SUM(`pu`.`total_amount`), 0) AS `purchase_amount` 
	    FROM
	      `products` `pr` 
	      LEFT JOIN `purchases` `pu` 
		ON (`pr`.`id` = `pu`.`product_id` AND pu.purchase_date BETWEEN fromDate AND toDate)
	    WHERE pr.store_id = storeId
	    GROUP BY `pr`.`id`) AS `p` -- purchase_product_report
	    LEFT JOIN 
	      (SELECT 
		`pr`.`id` AS `id`,
		`pr`.`store_id` AS `store_id`,
		COALESCE(SUM(`s`.`total_units`), 0) AS `sale_qty`,
		COALESCE(SUM(`s`.`total_amount`), 0) AS `sale_amount` 
	      FROM
		`products` `pr` 
		LEFT JOIN `sales` `s` 
		  ON (`pr`.`id` = `s`.`product_id` AND s.sale_date BETWEEN fromDate AND toDate)
	      WHERE pr.store_id = storeId 
	      GROUP BY `pr`.`id`) `s` 
	      ON `s`.`id` = `p`.`id` -- `product_sale_report`
	    LEFT JOIN 
	      (
			  SELECT 
				`pr`.`id` AS `id`,
				`pr`.`store_id` AS `store_id`,
				COALESCE(SUM(`b`.`total_units`), 0) AS `breakage_qty`,
				COALESCE(SUM(`b`.`total_amount`), 0) AS `breakage_amount` 
				  FROM
				(
				  `products` `pr` 
				  LEFT JOIN `breakages` `b` 
					ON (`pr`.`id` = `b`.`product_id` AND b.breakage_date BETWEEN fromDate AND toDate)
				) 
			  WHERE pr.store_id = storeId 
			  GROUP BY `pr`.`id`
		  ) `b` ON `b`.`id` = `p`.`id` -- product_breakage_report
		LEFT JOIN 
	      (
			  SELECT 
				`pr`.`id` AS `id`,
				`pr`.`store_id` AS `store_id`,
				COALESCE(SUM(`sto`.`total_units`), 0) AS `stock_transfer_out_qty`,
				COALESCE(SUM(`sto`.`total_amount`), 0) AS `stock_transfer_out_amount` 
				  FROM
				(
				  `products` `pr` 
				  LEFT JOIN `stock_transfer_outs` `sto` 
					ON (`pr`.`id` = `sto`.`product_id` AND sto.transfer_out_date BETWEEN fromDate AND toDate)
				) 
			  WHERE pr.store_id = storeId 
			  GROUP BY `pr`.`id`
		  ) `sto` ON `sto`.`id` = `p`.`id` -- stock_transfer_out_report 
		LEFT JOIN 
	      (
			  SELECT 
				`pr`.`id` AS `id`,
				`pr`.`store_id` AS `store_id`,
				COALESCE(SUM(`sti`.`total_units`), 0) AS `stock_transfer_in_qty`,
				COALESCE(SUM(`sti`.`total_amount`), 0) AS `stock_transfer_in_amount` 
				  FROM
				(
				  `products` `pr` 
				  LEFT JOIN `stock_transfer_ins` `sti` 
					ON (`pr`.`id` = `sti`.`product_id` AND sti.transfer_in_date BETWEEN fromDate AND toDate)
				) 
			  WHERE pr.store_id = storeId 
			  GROUP BY `pr`.`id`
		  ) `sti` ON `sti`.`id` = `p`.`id` -- stock_transfer_in_report    
		  
	    LEFT JOIN `product_categories` `c` 
	      ON `c`.`id` = `p`.`product_category_id` 
		LEFT JOIN `brands` `br` 
		  ON `br`.`id` = `p`.`brand_id`
	  WHERE p.store_id = storeId 
	    AND s.store_id = storeId 
	    AND b.store_id = storeId 
	    AND sto.store_id = storeId 
	    AND sti.store_id = storeId;
	
    END$$

DROP PROCEDURE IF EXISTS `product_stock_report`$$
CREATE DEFINER=`root`@`%` PROCEDURE `product_stock_report` (IN `storeId` INT)   BEGIN
	
	SELECT 
	    `p`.`id` AS `product_id`,
	    `p`.`product_name` AS `product_name`,
	    `p`.`brand_id`,
	    `p`.`unit_selling_price` AS `unit_selling_price`,
	    `p`.`box_buying_price` AS `box_buying_price`,
	    `p`.`box_qty` AS `box_qty`,
	    `br`.`name` AS `brand_name`,
	    `c`.`id` AS `category_id`,
	    `c`.`name` AS `category_name`,
	    `p`.`store_id` AS `store_id`,
	    COALESCE(`p`.`purchase_qty`, 0) AS `purchase_qty`,
	    COALESCE(`p`.`purchase_amount`, 0) AS `purchase_amount`,
	    COALESCE(`s`.`sale_qty`, 0) AS `sale_qty`,
	    COALESCE(`s`.`sale_amount`, 0) AS `sale_amount`,
	    COALESCE(`b`.`breakage_qty`, 0) AS `breakage_qty`,
	    COALESCE(`b`.`breakage_amount`, 0) AS `breakage_amount`,
	    COALESCE(`sto`.`stock_transfer_out_qty`, 0) AS `stock_transfer_out_qty`,
	    COALESCE(`sto`.`stock_transfer_out_amount`, 0) AS `stock_transfer_out_amount`,
	    COALESCE(`sti`.`stock_transfer_in_qty`, 0) AS `stock_transfer_in_qty`,
	    COALESCE(`sti`.`stock_transfer_in_amount`, 0) AS `stock_transfer_in_amount`,
	    (
	      COALESCE(`p`.`purchase_qty`, 0) 
	      + COALESCE(`sti`.`stock_transfer_in_qty`, 0) 
	      - COALESCE(`s`.`sale_qty`, 0) 
	      - COALESCE(`b`.`breakage_qty`, 0) 
	      - COALESCE(`sto`.`stock_transfer_out_qty`, 0)
	    ) AS `balance_qty`,
	    (
	      COALESCE(`s`.`sale_amount`, 0) 
	      + COALESCE(`sto`.`stock_transfer_out_amount`, 0) 
	      - COALESCE(`p`.`purchase_amount`, 0) 
	      - COALESCE(`b`.`breakage_qty`, 0)
	      - COALESCE(`sti`.`stock_transfer_in_amount`, 0) 
	    ) AS `profit_amount` 
	  FROM
	    (
			SELECT 
				`pr`.`id` AS `id`,
				`pr`.`name` AS `product_name`,
				`pr`.`brand_id` AS `brand_id`,
				`pr`.`unit_selling_price` AS `unit_selling_price`,
				`pr`.`box_buying_price` AS `box_buying_price`,
				`pr`.`box_qty` AS `box_qty`,
				`pr`.`product_category_id` AS `product_category_id`,
				`pr`.`store_id` AS `store_id`,
				COALESCE(SUM(`pu`.`total_units`), 0) AS `purchase_qty`,
				COALESCE(SUM(`pu`.`total_amount`), 0) AS `purchase_amount` 
			FROM
			  `products` `pr` 
			  LEFT JOIN `purchases` `pu` 
			ON `pr`.`id` = `pu`.`product_id` 
			WHERE pr.store_id = storeId 
			GROUP BY `pr`.`id`
		) AS `p` -- purchase_product_report
	    LEFT JOIN 
	      (
			SELECT 
				`pr`.`id` AS `id`,
				`pr`.`store_id` AS `store_id`,
				COALESCE(SUM(`s`.`total_units`), 0) AS `sale_qty`,
				COALESCE(SUM(`s`.`total_amount`), 0) AS `sale_amount` 
			FROM
				`products` `pr` 
			LEFT JOIN `sales` `s` 
				ON `pr`.`id` = `s`.`product_id` 
			WHERE pr.store_id = storeId 
			GROUP BY `pr`.`id`
		  ) `s` ON `s`.`id` = `p`.`id` -- `product_sale_report`
	    LEFT JOIN 
	      (
			  SELECT 
				`pr`.`id` AS `id`,
				`pr`.`store_id` AS `store_id`,
				COALESCE(SUM(`b`.`total_units`), 0) AS `breakage_qty`,
				COALESCE(SUM(`b`.`total_amount`), 0) AS `breakage_amount` 
				  FROM
				(
				  `products` `pr` 
				  LEFT JOIN `breakages` `b` 
					ON ((`pr`.`id` = `b`.`product_id`))
				) 
			  WHERE pr.store_id = storeId 
			  GROUP BY `pr`.`id`
		  ) `b` ON `b`.`id` = `p`.`id` -- product_breakage_report
		LEFT JOIN 
	      (
			  SELECT 
				`pr`.`id` AS `id`,
				`pr`.`store_id` AS `store_id`,
				COALESCE(SUM(`sto`.`total_units`), 0) AS `stock_transfer_out_qty`,
				COALESCE(SUM(`sto`.`total_amount`), 0) AS `stock_transfer_out_amount` 
				  FROM
				(
				  `products` `pr` 
				  LEFT JOIN `stock_transfer_outs` `sto` 
					ON ((`pr`.`id` = `sto`.`product_id`))
				) 
			  WHERE pr.store_id = storeId 
			  GROUP BY `pr`.`id`
		  ) `sto` ON `sto`.`id` = `p`.`id` -- stock_transfer_out_report 
		LEFT JOIN 
	      (
			  SELECT 
				`pr`.`id` AS `id`,
				`pr`.`store_id` AS `store_id`,
				COALESCE(SUM(`sti`.`total_units`), 0) AS `stock_transfer_in_qty`,
				COALESCE(SUM(`sti`.`total_amount`), 0) AS `stock_transfer_in_amount` 
				  FROM
				(
				  `products` `pr` 
				  LEFT JOIN `stock_transfer_ins` `sti` 
					ON ((`pr`.`id` = `sti`.`product_id`))
				) 
			  WHERE pr.store_id = storeId 
			  GROUP BY `pr`.`id`
		  ) `sti` ON `sti`.`id` = `p`.`id` -- stock_transfer_in_report  
	    LEFT JOIN `product_categories` `c` 
	      ON `c`.`id` = `p`.`product_category_id` 
		LEFT JOIN `brands` `br` 
		  ON `br`.`id` = `p`.`brand_id`
	  WHERE p.store_id = storeId 
	    AND s.store_id = storeId 
	    AND b.store_id = storeId 
	    AND sto.store_id = storeId 
	    AND sti.store_id = storeId;
	
    END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `attendances`
--

DROP TABLE IF EXISTS `attendances`;
CREATE TABLE IF NOT EXISTS `attendances` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `type` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `login_time` time DEFAULT NULL,
  `logout_time` time DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `banks`
--

DROP TABLE IF EXISTS `banks`;
CREATE TABLE IF NOT EXISTS `banks` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `store_id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `payment_type` enum('credit','debit') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `payment_date` date NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bank_balance_book`
--

DROP TABLE IF EXISTS `bank_balance_book`;
CREATE TABLE IF NOT EXISTS `bank_balance_book` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `store_id` bigint UNSIGNED NOT NULL,
  `particulars` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `amount` decimal(12,2) DEFAULT NULL,
  `payment_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`),
  KEY `store_id_payment_date` (`store_id`,`payment_date`),
  KEY `payment_date` (`payment_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

DROP TABLE IF EXISTS `bills`;
CREATE TABLE IF NOT EXISTS `bills` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `store_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `items_count` int NOT NULL DEFAULT '0',
  `items_quantity` int NOT NULL DEFAULT '0',
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tax` decimal(10,2) NOT NULL DEFAULT '0.00',
  `bill_date` datetime NOT NULL,
  `total_bill_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
CREATE TABLE IF NOT EXISTS `brands` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_brand_id` bigint UNSIGNED NOT NULL,
  `store_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `dealer_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`),
  KEY `dealer_id` (`dealer_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `group_brand_id`, `store_id`, `name`, `created`, `modified`, `dealer_id`, `user_id`) VALUES
(1, 4, 2, 'Blenders', '2025-09-17 13:07:40', '2025-09-17 13:07:40', NULL, 1),
(2, 6, 2, 'Haywards', '2025-09-17 13:07:40', '2025-09-17 13:07:40', NULL, 1),
(3, 2, 2, 'King Fisher', '2025-09-17 13:07:40', '2025-09-17 13:07:40', NULL, 1),
(4, 4, 3, 'Blenders', '2025-09-22 20:18:27', '2025-09-22 20:25:58', NULL, 1),
(5, 1, 3, 'Haywards', '2025-09-22 20:18:27', '2025-09-22 20:25:58', NULL, 1),
(6, 6, 3, 'King Fisher', '2025-09-22 20:18:27', '2025-09-22 20:25:58', NULL, 1),
(7, 2, 3, 'Mansion House', '2025-09-22 20:18:27', '2025-09-22 20:25:58', NULL, 1),
(8, 3, 3, 'Royal Stag', '2025-09-22 20:18:27', '2025-09-22 20:25:58', NULL, 1),
(9, 4, 4, 'Blenders', '2025-09-22 20:22:59', '2025-09-22 20:26:08', NULL, 1),
(10, 4, 4, 'Brand-X', '2025-09-22 20:22:59', '2025-09-22 20:23:03', NULL, 1),
(11, 4, 4, 'Haywards', '2025-09-22 20:22:59', '2025-09-22 20:23:03', NULL, 1),
(12, 1, 4, 'Haywards', '2025-09-22 20:22:59', '2025-09-22 20:26:08', NULL, 1),
(13, 1, 4, 'King Fisher', '2025-09-22 20:22:59', '2025-09-22 20:26:08', NULL, 1),
(14, 1, 4, 'Mansion House', '2025-09-22 20:22:59', '2025-09-22 20:26:08', NULL, 1),
(15, 1, 4, 'Haywards', '2025-09-22 20:22:59', '2025-09-22 20:26:08', NULL, 1),
(16, 1, 4, 'King Fisher', '2025-09-22 20:22:59', '2025-09-22 20:26:08', NULL, 1),
(17, 1, 4, 'Mansion House', '2025-09-22 20:22:59', '2025-09-22 20:26:08', NULL, 1),
(18, 4, 5, 'Blenders', '2025-09-22 20:25:40', '2025-09-22 20:25:40', NULL, 1),
(19, 1, 5, 'Brand-X', '2025-09-22 20:25:40', '2025-09-22 20:25:40', NULL, 1),
(20, 6, 5, 'Haywards', '2025-09-22 20:25:40', '2025-09-22 20:25:40', NULL, 1),
(21, 2, 5, 'King Fisher', '2025-09-22 20:25:40', '2025-09-22 20:25:40', NULL, 1),
(22, 3, 5, 'Mansion House', '2025-09-22 20:25:40', '2025-09-22 20:25:40', NULL, 1),
(23, 5, 5, 'Royal Stag', '2025-09-22 20:25:40', '2025-09-22 20:25:40', NULL, 1),
(24, 1, 3, 'Brand-X', '2025-09-22 20:18:27', '2025-09-22 20:25:58', NULL, 1),
(25, 6, 3, 'Haywards', '2025-09-22 20:18:27', '2025-09-22 20:25:58', NULL, 1),
(26, 2, 3, 'King Fisher', '2025-09-22 20:18:27', '2025-09-22 20:25:58', NULL, 1),
(27, 3, 3, 'Mansion House', '2025-09-22 20:18:27', '2025-09-22 20:25:58', NULL, 1),
(28, 1, 4, 'Brand-X', '2025-09-22 20:22:59', '2025-09-22 20:26:08', NULL, 1),
(29, 5, 4, 'Royal Stag', '2025-09-22 20:22:59', '2025-09-22 20:26:08', NULL, 1),
(30, 4, 1, 'Blenders', '2025-09-22 20:28:22', '2025-09-22 20:28:22', NULL, NULL),
(31, 2, 1, 'King Fisher', '2025-09-22 20:31:27', '2025-09-28 15:24:40', NULL, NULL),
(32, 3, 2, 'Mansion House', '2025-09-22 20:31:27', '2025-09-22 20:31:27', NULL, NULL),
(33, 3, 1, 'Mansion House', '2025-09-22 20:31:27', '2025-09-22 20:31:27', NULL, NULL),
(34, 5, 2, 'Royal Stag', '2025-09-22 20:31:27', '2025-09-22 20:31:27', NULL, NULL),
(35, 5, 1, 'Royal Stag', '2025-09-22 20:31:27', '2025-09-22 20:31:27', NULL, NULL),
(36, 6, 1, 'Haywards', '2025-09-28 15:24:40', '2025-09-28 15:24:40', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `breakages`
--

DROP TABLE IF EXISTS `breakages`;
CREATE TABLE IF NOT EXISTS `breakages` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_code` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `product_category_id` bigint UNSIGNED NOT NULL,
  `store_id` bigint UNSIGNED NOT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `total_units` int UNSIGNED DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT NULL,
  `breakage_date` date DEFAULT NULL,
  `product_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `category_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `store_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_category_id` (`product_category_id`),
  KEY `store_id_product_id` (`store_id`,`product_id`),
  KEY `store_id_breakage_date` (`store_id`,`breakage_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cashbook`
--

DROP TABLE IF EXISTS `cashbook`;
CREATE TABLE IF NOT EXISTS `cashbook` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` bigint UNSIGNED NOT NULL,
  `category_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_amount` decimal(10,2) DEFAULT NULL,
  `payment_type` enum('income','expense') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'expense',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `store_id` bigint UNSIGNED NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `store_id_payment_date` (`store_id`,`payment_date`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cashbook`
--

INSERT INTO `cashbook` (`id`, `category_id`, `category_name`, `payment_date`, `payment_amount`, `payment_type`, `description`, `store_id`, `created`, `modified`) VALUES
(1, 1, 'Depo', '2025-09-22', 5000.00, 'expense', '', 3, '2025-09-22 20:28:47', '2025-09-22 20:28:47'),
(2, 2, 'Excise', '2025-09-22', 6500.00, 'income', 'Excise', 3, '2025-09-22 20:28:56', '2025-09-22 20:28:56'),
(3, 3, 'Depo', '2025-09-28', 55.00, 'expense', 'depo', 5, '2025-09-28 15:26:10', '2025-09-28 15:26:10'),
(4, 4, 'Depo', '2025-09-28', 8555.00, 'expense', '', 2, '2025-09-28 15:27:11', '2025-09-28 15:27:11'),
(5, 4, 'Depo', '2025-10-11', 5555.00, 'expense', '', 2, '2025-10-11 14:51:15', '2025-10-11 14:51:15'),
(8, 6, 'Auto Charge', '2025-10-30', 1000.00, 'expense', 'Auto-1000', 9, '2025-11-10 07:12:20', '2025-11-10 07:12:20'),
(9, 7, 'Depo', '2025-10-30', 6320.00, 'expense', 'I.M.L-6320', 9, '2025-11-10 07:13:03', '2025-11-10 07:13:03'),
(10, 6, 'Auto Charge', '2025-10-29', 1000.00, 'expense', 'Auto-1000', 9, '2025-11-10 07:16:48', '2025-11-10 07:16:48'),
(11, 6, 'Auto Charge', '2025-10-31', 1000.00, 'expense', 'Auto-1000', 9, '2025-11-10 07:33:17', '2025-11-10 07:33:17'),
(12, 6, 'Auto Charge', '2025-10-31', 31000.00, 'expense', '2 Autos-31000', 9, '2025-11-10 07:34:14', '2025-11-10 07:34:14'),
(13, 10, 'Shop', '2025-10-31', 250.00, 'expense', 'puja-250', 9, '2025-11-10 07:35:04', '2025-11-10 07:35:04'),
(14, 11, 'Salary', '2025-10-31', 75000.00, 'expense', 'salary- 75000', 9, '2025-11-10 07:36:26', '2025-11-10 07:36:26'),
(15, 12, 'Brokerage Charges', '2025-10-31', 6270.00, 'expense', 'Brokerage-6270', 9, '2025-11-10 07:36:53', '2025-11-10 07:36:53'),
(16, 13, 'Shelter Rent', '2025-10-31', 8000.00, 'expense', 'Shelter rent-8000', 9, '2025-11-10 07:37:12', '2025-11-10 07:37:12'),
(17, 6, 'Auto Charge', '2025-11-01', 1000.00, 'expense', 'Auto-1000', 9, '2025-11-10 07:55:41', '2025-11-10 07:55:41'),
(18, 14, 'Stationary', '2025-11-01', 1000.00, 'expense', 'Sationary-1000', 9, '2025-11-10 07:56:55', '2025-11-10 07:56:55');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '',
  `active` tinyint DEFAULT '1',
  `store_id` bigint UNSIGNED NOT NULL,
  `expense` tinyint DEFAULT '0',
  `income` tinyint DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `storewise_income_report` tinyint DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `active`, `store_id`, `expense`, `income`, `created`, `modified`, `storewise_income_report`) VALUES
(1, 'Depo', 1, 3, 1, 0, '2025-09-22 20:28:37', '2025-09-22 20:28:37', 1),
(2, 'Excise', 1, 3, 0, 1, '2025-09-22 20:28:41', '2025-09-22 20:28:41', 1),
(3, 'Depo', 1, 5, 1, 0, '2025-09-28 15:26:00', '2025-09-28 15:26:00', 1),
(4, 'Depo', 1, 2, 1, 0, '2025-09-28 15:26:51', '2025-09-28 15:26:51', 1),
(5, 'Excise', 1, 2, 0, 0, '2025-09-28 15:27:00', '2025-09-28 15:27:00', 1),
(6, 'Auto Charge', 1, 9, 1, 0, '2025-10-23 07:21:30', '2025-10-23 07:21:30', 1),
(7, 'Depo', 1, 9, 1, 0, '2025-10-23 07:21:37', '2025-10-23 07:21:37', 1),
(8, 'Puja Samgri', 1, 9, 1, 0, '2025-10-23 07:24:32', '2025-10-23 07:24:32', 1),
(9, 'Police', 1, 9, 1, 0, '2025-10-23 07:25:08', '2025-10-23 07:25:08', 1),
(10, 'Shop', 1, 9, 1, 0, '2025-11-10 07:34:38', '2025-11-10 07:34:38', 1),
(11, 'Salary', 1, 9, 1, 0, '2025-11-10 07:35:20', '2025-11-10 07:35:20', 1),
(12, 'Brokerage Charges', 1, 9, 1, 0, '2025-11-10 07:35:43', '2025-11-10 07:35:43', 1),
(13, 'Shelter Rent', 1, 9, 1, 0, '2025-11-10 07:36:00', '2025-11-10 07:36:00', 1),
(14, 'Stationary', 1, 9, 1, 0, '2025-11-10 07:56:18', '2025-11-10 07:56:18', 1);

-- --------------------------------------------------------

--
-- Table structure for table `counter_balance_sheets`
--

DROP TABLE IF EXISTS `counter_balance_sheets`;
CREATE TABLE IF NOT EXISTS `counter_balance_sheets` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `store_id` bigint UNSIGNED NOT NULL,
  `opening_balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_sales` decimal(10,2) NOT NULL DEFAULT '0.00',
  `counter_cash` decimal(10,2) NOT NULL DEFAULT '0.00',
  `counter_cash_by_card` decimal(10,2) NOT NULL,
  `expenses` decimal(10,2) NOT NULL DEFAULT '0.00',
  `closing_balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `transaction_balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `short_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dealers`
--

DROP TABLE IF EXISTS `dealers`;
CREATE TABLE IF NOT EXISTS `dealers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `store_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `default_price_lists`
--

DROP TABLE IF EXISTS `default_price_lists`;
CREATE TABLE IF NOT EXISTS `default_price_lists` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `brand_number` int DEFAULT NULL,
  `size_code` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `pack_type` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `product_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `issue_price` decimal(10,2) DEFAULT NULL,
  `special_margin` decimal(5,2) DEFAULT NULL,
  `mrp` decimal(10,2) DEFAULT NULL,
  `type` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
CREATE TABLE IF NOT EXISTS `employees` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `joining_date` date DEFAULT NULL,
  `last_working_date` date DEFAULT NULL,
  `store_id` bigint UNSIGNED NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `active` tinyint DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `beverage_invoice_upload` tinyint DEFAULT '0',
  `state` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'TG',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `active`, `created`, `modified`, `beverage_invoice_upload`, `state`) VALUES
(1, 'KK Syndicate', 1, '2025-09-08 20:55:00', '2025-09-08 20:55:00', 0, 'TG'),
(2, 'M B Group', 1, '2025-09-17 12:58:09', '2025-09-17 12:58:09', 0, 'TG'),
(3, 'MDK Belt', 1, '2025-09-27 21:03:17', '2025-10-16 19:28:01', 0, 'TG'),
(4, 'ZHB Gangwar', 1, '2025-11-09 09:49:37', '2025-11-09 09:49:37', 0, 'TG');

-- --------------------------------------------------------

--
-- Table structure for table `group_brands`
--

DROP TABLE IF EXISTS `group_brands`;
CREATE TABLE IF NOT EXISTS `group_brands` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `active` tinyint DEFAULT '1',
  `name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `group_id` bigint NOT NULL,
  `group_dealer_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `group_brands`
--

INSERT INTO `group_brands` (`id`, `active`, `name`, `code`, `created`, `modified`, `group_id`, `group_dealer_id`) VALUES
(1, 1, 'Brand-X', NULL, '2025-09-08 20:55:00', '2025-09-08 22:13:38', 1, 2),
(2, 1, 'King Fisher', 'KF001', '2025-09-08 21:01:38', '2025-09-08 22:13:38', 1, 1),
(3, 1, 'Mansion House', NULL, '2025-09-08 22:10:55', '2025-09-08 22:13:38', 1, 3),
(4, 1, 'Blenders', NULL, '2025-09-08 22:11:14', '2025-09-08 22:13:38', 1, 2),
(5, 1, 'Royal Stag', NULL, '2025-09-08 22:11:50', '2025-09-08 22:13:38', 1, 3),
(6, 1, 'Haywards', NULL, '2025-09-08 22:12:40', '2025-09-08 22:13:38', 1, 1),
(7, 1, 'Brand-X', NULL, '2025-09-17 12:58:09', '2025-09-17 12:58:09', 2, 4),
(8, 1, 'Kingfisher', NULL, '2025-09-27 21:03:17', '2025-11-09 10:06:57', 3, 5),
(9, 1, 'Brand-X', NULL, '2025-11-09 09:49:37', '2025-11-09 09:49:37', 4, 6),
(10, 1, 'Haywards', NULL, '2025-11-09 10:08:35', '2025-11-09 10:08:35', 3, 5),
(11, 1, 'Mc', NULL, '2025-11-09 10:09:47', '2025-11-09 10:10:33', 3, 7);

-- --------------------------------------------------------

--
-- Table structure for table `group_dealers`
--

DROP TABLE IF EXISTS `group_dealers`;
CREATE TABLE IF NOT EXISTS `group_dealers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `active` tinyint DEFAULT '1',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `group_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `group_dealers`
--

INSERT INTO `group_dealers` (`id`, `active`, `name`, `created`, `modified`, `group_id`) VALUES
(1, 1, 'D-Shankar', '2025-09-08 20:55:00', '2025-09-08 22:10:15', 1),
(2, 1, 'D-Preetham', '2025-09-08 22:10:24', '2025-09-08 22:10:24', 1),
(3, 1, 'D-KP', '2025-09-08 22:10:32', '2025-09-08 22:10:32', 1),
(4, 1, 'Dealer-X', '2025-09-17 12:58:09', '2025-09-17 12:58:09', 2),
(5, 1, 'Preetham KF', '2025-09-27 21:03:17', '2025-11-09 10:07:35', 3),
(6, 1, 'Dealer-X', '2025-11-09 09:49:37', '2025-11-09 09:49:37', 4),
(7, 1, 'prakash Mc', '2025-11-09 10:10:10', '2025-11-09 10:10:10', 3);

-- --------------------------------------------------------

--
-- Table structure for table `group_products`
--

DROP TABLE IF EXISTS `group_products`;
CREATE TABLE IF NOT EXISTS `group_products` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `shortcut_key` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `product_code` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `active` tinyint DEFAULT '1',
  `sort` smallint DEFAULT NULL,
  `box_buying_price` decimal(10,2) DEFAULT NULL,
  `box_selling_price` decimal(10,2) DEFAULT NULL,
  `box_qty` int UNSIGNED DEFAULT NULL,
  `unit_buying_price` decimal(10,2) DEFAULT NULL,
  `unit_selling_price` decimal(10,2) DEFAULT NULL,
  `special_margin` decimal(10,2) DEFAULT '0.00',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `has_variants` tinyint DEFAULT '0',
  `measuring_unit` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `measuring_unit_value` decimal(10,2) DEFAULT '0.00',
  `inventory_tracking` tinyint DEFAULT '1',
  `group_id` bigint UNSIGNED NOT NULL,
  `group_product_category_id` bigint UNSIGNED NOT NULL,
  `group_brand_id` bigint UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `active` (`active`),
  KEY `productCategoryIdProductsIndex` (`group_product_category_id`),
  KEY `brand_id` (`group_brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `group_products`
--

INSERT INTO `group_products` (`id`, `shortcut_key`, `name`, `product_code`, `active`, `sort`, `box_buying_price`, `box_selling_price`, `box_qty`, `unit_buying_price`, `unit_selling_price`, `special_margin`, `created`, `modified`, `has_variants`, `measuring_unit`, `measuring_unit_value`, `inventory_tracking`, `group_id`, `group_product_category_id`, `group_brand_id`) VALUES
(1, NULL, 'KF - 650ml', '1001', 1, NULL, 2400.00, NULL, 12, NULL, 250.00, 0.00, '2025-09-08 21:02:19', '2025-09-08 22:13:04', 0, 'ml', 650.00, 1, 1, 3, 2),
(2, NULL, 'KF - 330ml', '1002', 1, NULL, 2400.00, NULL, 24, NULL, 125.00, 0.00, '2025-09-08 21:02:49', '2025-09-08 22:13:04', 0, 'ml', 330.00, 1, 1, 3, 2),
(3, NULL, 'Haywards - 650ml', '2001', 1, NULL, 2400.00, NULL, 12, NULL, 275.00, 0.00, '2025-09-08 21:03:30', '2025-09-08 22:13:04', 0, 'ml', 650.00, 1, 1, 3, 6),
(4, NULL, 'Haywards - 330ml', '2002', 1, NULL, 2400.00, NULL, 24, NULL, 140.00, 0.00, '2025-09-08 21:04:24', '2025-09-08 22:13:04', 0, 'ml', 330.00, 1, 1, 3, 6),
(5, NULL, 'Blenders Q', '5001', 1, NULL, 4800.00, NULL, 12, NULL, 500.00, 0.00, '2025-09-08 22:15:48', '2025-09-08 22:15:48', 0, 'ml', 750.00, 1, 1, 1, 4),
(6, NULL, 'Blenders P', '5002', 1, NULL, 4800.00, NULL, 24, NULL, 250.00, 0.00, '2025-09-08 22:16:13', '2025-09-08 22:16:13', 0, 'ml', 375.00, 1, 1, 1, 4),
(7, NULL, 'Blenders N', '5003', 1, NULL, 4800.00, NULL, 48, NULL, 125.00, 0.00, '2025-09-08 22:16:46', '2025-09-08 22:16:46', 0, 'ml', 180.00, 1, 1, 1, 4),
(8, NULL, 'M H W - Q', '5100', 1, NULL, 3600.00, NULL, 12, NULL, 350.00, 0.00, '2025-09-08 22:18:31', '2025-09-08 22:18:31', 0, 'ml', 750.00, 1, 1, 1, 3),
(9, NULL, 'M H W - P', '5101', 1, NULL, 3600.00, NULL, 24, NULL, 175.00, 0.00, '2025-09-08 22:19:16', '2025-09-08 22:19:16', 0, 'ml', 375.00, 1, 1, 1, 3),
(10, NULL, 'Royal Stag N', '5200', 1, NULL, 4800.00, NULL, 48, NULL, 125.00, 0.00, '2025-09-08 22:19:54', '2025-09-08 22:19:54', 0, 'ml', 180.00, 1, 1, 1, 5),
(11, NULL, 'Brand-X D', '10000', 1, NULL, 9600.00, NULL, 96, NULL, 120.00, 0.00, '2025-09-08 22:22:05', '2025-09-08 22:22:05', 0, 'ml', 90.00, 1, 1, 2, 1),
(12, NULL, 'BUDWEISER-650ML', '', 1, NULL, 1801.00, NULL, 12, NULL, 210.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 650.00, 1, 3, 4, NULL),
(13, NULL, 'KF PREMIUM - 650ML', '', 1, NULL, 1501.00, NULL, 12, NULL, 190.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 650.00, 1, 3, 4, NULL),
(14, NULL, 'KF STRONG - 650ML', '', 1, NULL, 1601.00, NULL, 12, NULL, 200.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 650.00, 1, 3, 4, NULL),
(15, NULL, 'KNOCKOUT-650ML', '', 1, NULL, 1601.00, NULL, 12, NULL, 200.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 650.00, 1, 3, 4, NULL),
(16, NULL, 'M H B - N', '', 1, NULL, 5604.00, NULL, 48, NULL, 190.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 180.00, 1, 3, 5, NULL),
(17, NULL, 'M H B O - N', '', 1, NULL, 7204.00, NULL, 48, NULL, 230.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 180.00, 1, 3, 5, NULL),
(18, NULL, 'BLENDER - N', '', 1, NULL, 12004.00, NULL, 48, NULL, 350.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 180.00, 1, 3, 6, NULL),
(19, NULL, 'BREEZER', '', 1, NULL, 2002.00, NULL, 24, NULL, 140.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 275.00, 1, 3, 6, NULL),
(20, NULL, 'CHEEP - N', '', 1, NULL, 3784.00, NULL, 48, NULL, 120.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 180.00, 1, 3, 6, NULL),
(21, NULL, 'DK Double Kick', '', 1, NULL, 3784.00, NULL, 24, NULL, 110.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 360.00, 1, 3, 6, NULL),
(22, NULL, 'IB - D', '', 1, NULL, 5608.00, NULL, 96, NULL, 95.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 90.00, 1, 3, 6, NULL),
(23, NULL, 'IB - N', '', 1, NULL, 6004.00, NULL, 48, NULL, 200.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 180.00, 1, 3, 6, NULL),
(24, NULL, 'Iconiq - N', '', 1, NULL, 6004.00, NULL, 48, NULL, 200.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 180.00, 1, 3, 6, NULL),
(25, NULL, 'MC LUXERY - D', '', 1, NULL, 5608.00, NULL, 96, NULL, 95.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 90.00, 1, 3, 6, NULL),
(26, NULL, 'MC LUXURY - N', '', 1, NULL, 6004.00, NULL, 48, NULL, 200.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 180.00, 1, 3, 6, NULL),
(27, NULL, 'OC WHISKY - D', '', 1, NULL, 5608.00, NULL, 96, NULL, 95.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 90.00, 1, 3, 6, NULL),
(28, NULL, 'OC WHISKY - N', '', 1, NULL, 5204.00, NULL, 48, NULL, 170.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 180.00, 1, 3, 6, NULL),
(29, NULL, 'ROYAL GREEN -N', '', 1, NULL, 7204.00, NULL, 48, NULL, 220.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 180.00, 1, 3, 6, NULL),
(30, NULL, 'ROYAL STAG - D', '', 1, NULL, 7208.00, NULL, 96, NULL, 115.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 90.00, 1, 3, 6, NULL),
(31, NULL, 'ROYAL STAG - N', '', 1, NULL, 7204.00, NULL, 48, NULL, 230.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 180.00, 1, 3, 6, NULL),
(32, NULL, 'SIGNATURE ULTRA - N', '', 1, NULL, 12004.00, NULL, 48, NULL, 350.00, 0.00, '2025-09-27 21:19:32', '2025-09-27 21:19:32', 0, 'ml', 180.00, 1, 3, 6, NULL),
(33, NULL, 'BUDWEISER-650ML', '', 1, NULL, 1801.00, NULL, 12, NULL, 210.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 650.00, 1, 4, 7, NULL),
(34, NULL, 'KF PREMIUM - 650ML', '', 1, NULL, 1501.00, NULL, 12, NULL, 190.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 650.00, 1, 4, 7, NULL),
(35, NULL, 'KF STRONG - 650ML', '', 1, NULL, 1601.00, NULL, 12, NULL, 200.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 650.00, 1, 4, 7, NULL),
(36, NULL, 'KNOCKOUT-650ML', '', 1, NULL, 1601.00, NULL, 12, NULL, 200.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 650.00, 1, 4, 7, NULL),
(37, NULL, 'M H B - N', '', 1, NULL, 5604.00, NULL, 48, NULL, 190.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 180.00, 1, 4, 8, NULL),
(38, NULL, 'M H B O - N', '', 1, NULL, 7204.00, NULL, 48, NULL, 230.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 180.00, 1, 4, 8, NULL),
(39, NULL, 'BLENDER - N', '', 1, NULL, 12004.00, NULL, 48, NULL, 350.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 180.00, 1, 4, 9, NULL),
(40, NULL, 'BREEZER', '', 1, NULL, 2002.00, NULL, 24, NULL, 140.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 275.00, 1, 4, 9, NULL),
(41, NULL, 'CHEEP - N', '', 1, NULL, 3784.00, NULL, 48, NULL, 120.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 180.00, 1, 4, 9, NULL),
(42, NULL, 'DK Double Kick', '', 1, NULL, 3784.00, NULL, 24, NULL, 110.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 360.00, 1, 4, 9, NULL),
(43, NULL, 'IB - D', '', 1, NULL, 5608.00, NULL, 96, NULL, 95.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 90.00, 1, 4, 9, NULL),
(44, NULL, 'IB - N', '', 1, NULL, 6004.00, NULL, 48, NULL, 200.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 180.00, 1, 4, 9, NULL),
(45, NULL, 'Iconiq - N', '', 1, NULL, 6004.00, NULL, 48, NULL, 200.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 180.00, 1, 4, 9, NULL),
(46, NULL, 'MC LUXERY - D', '', 1, NULL, 5608.00, NULL, 96, NULL, 95.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 90.00, 1, 4, 9, NULL),
(47, NULL, 'MC LUXURY - N', '', 1, NULL, 6004.00, NULL, 48, NULL, 200.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 180.00, 1, 4, 9, NULL),
(48, NULL, 'OC WHISKY - D', '', 1, NULL, 5608.00, NULL, 96, NULL, 95.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 90.00, 1, 4, 9, NULL),
(49, NULL, 'OC WHISKY - N', '', 1, NULL, 5204.00, NULL, 48, NULL, 170.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 180.00, 1, 4, 9, NULL),
(50, NULL, 'ROYAL GREEN -N', '', 1, NULL, 7204.00, NULL, 48, NULL, 220.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 180.00, 1, 4, 9, NULL),
(51, NULL, 'ROYAL STAG - D', '', 1, NULL, 7208.00, NULL, 96, NULL, 115.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 90.00, 1, 4, 9, NULL),
(52, NULL, 'ROYAL STAG - N', '', 1, NULL, 7204.00, NULL, 48, NULL, 230.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 180.00, 1, 4, 9, NULL),
(53, NULL, 'SIGNATURE ULTRA - N', '', 1, NULL, 12004.00, NULL, 48, NULL, 350.00, 0.00, '2025-11-09 10:01:06', '2025-11-09 10:01:06', 0, 'ml', 180.00, 1, 4, 9, NULL),
(54, NULL, 'KF Strong - 650 ml', '', 1, NULL, 1601.00, NULL, 12, NULL, 200.00, 0.00, '2025-11-09 10:21:06', '2025-11-09 10:21:06', 0, 'ml', 650.00, 1, 3, 4, 8);

-- --------------------------------------------------------

--
-- Table structure for table `group_product_categories`
--

DROP TABLE IF EXISTS `group_product_categories`;
CREATE TABLE IF NOT EXISTS `group_product_categories` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `active` tinyint DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `tag` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `group_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `active` (`active`),
  KEY `group_id` (`group_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `group_product_categories`
--

INSERT INTO `group_product_categories` (`id`, `name`, `type`, `active`, `created`, `modified`, `tag`, `group_id`) VALUES
(1, 'Whisky', NULL, 1, '2025-09-08 21:00:46', '2025-09-08 21:00:46', 'IML', 1),
(2, 'Wine', NULL, 1, '2025-09-08 21:00:51', '2025-09-08 21:01:01', 'BEER', 1),
(3, 'Beer', NULL, 1, '2025-09-08 21:00:56', '2025-09-08 21:00:56', 'IML', 1),
(4, 'BEER', NULL, 1, '2025-09-27 21:19:32', '2025-09-27 21:19:32', NULL, 3),
(5, 'Brandy', NULL, 1, '2025-09-27 21:19:32', '2025-09-27 21:19:32', NULL, 3),
(6, 'Whisky', NULL, 1, '2025-09-27 21:19:32', '2025-09-27 21:19:32', NULL, 3),
(7, 'BEER', NULL, 1, '2025-11-09 10:01:06', '2025-11-09 10:01:06', NULL, 4),
(8, 'Brandy', NULL, 1, '2025-11-09 10:01:06', '2025-11-09 10:01:06', NULL, 4),
(9, 'Whisky', NULL, 1, '2025-11-09 10:01:06', '2025-11-09 10:01:06', NULL, 4);

-- --------------------------------------------------------

--
-- Table structure for table `group_product_variants`
--

DROP TABLE IF EXISTS `group_product_variants`;
CREATE TABLE IF NOT EXISTS `group_product_variants` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `shortcut_key` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `product_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `group_product_id` bigint UNSIGNED NOT NULL,
  `active` smallint DEFAULT '1',
  `sort` smallint DEFAULT '0',
  `measuring_unit_value` decimal(10,2) DEFAULT '0.00',
  `measuring_unit` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `unit_selling_price` decimal(10,2) DEFAULT '0.00',
  `discount_percentage` decimal(10,2) DEFAULT '0.00',
  `discount_amount` decimal(10,2) DEFAULT '0.00',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `group_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `group_stores`
--

DROP TABLE IF EXISTS `group_stores`;
CREATE TABLE IF NOT EXISTS `group_stores` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_id` bigint UNSIGNED NOT NULL,
  `store_id` bigint UNSIGNED NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
CREATE TABLE IF NOT EXISTS `invoices` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `details` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `store_id` bigint UNSIGNED NOT NULL,
  `invoice_date` date DEFAULT NULL,
  `supplier_id` bigint UNSIGNED DEFAULT NULL,
  `supplier_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `dd_no` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `dd_amount` decimal(12,2) DEFAULT NULL,
  `dd_purchase` decimal(12,2) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `tax` decimal(10,2) DEFAULT '0.00',
  `invoice_value` decimal(12,2) DEFAULT NULL,
  `special_margin` decimal(10,2) DEFAULT NULL,
  `tcs_percent` decimal(10,1) DEFAULT NULL,
  `tcs_value` decimal(10,2) DEFAULT NULL,
  `prev_credit` decimal(10,2) DEFAULT NULL,
  `credit_balance` decimal(10,2) DEFAULT NULL,
  `mrp_rounding_off` decimal(10,2) DEFAULT '0.00',
  `retail_shop_excise_turnover_tax` decimal(10,2) DEFAULT '0.00',
  `special_excise_cess` decimal(10,2) DEFAULT '0.00',
  `new_retailer_prof_tax` decimal(10,2) DEFAULT '0.00',
  `ap_issue_price` decimal(12,2) DEFAULT '0.00',
  `ap_cess` decimal(10,2) DEFAULT '0.00',
  `ap_addl_prev_fee` decimal(10,2) DEFAULT '0.00',
  `ap_retail_excise_tax` decimal(10,2) DEFAULT '0.00',
  `ap_spl_prev_fee` decimal(10,2) DEFAULT '0.00',
  `ap_icdc_value` decimal(12,2) DEFAULT '0.00',
  `ap_tcs` decimal(10,2) DEFAULT '0.00',
  `ap_challan_no` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `ap_dd_amount` decimal(12,2) DEFAULT '0.00',
  `ap_previous_cr` decimal(10,2) DEFAULT '0.00',
  `ap_cr_balance` decimal(10,2) DEFAULT '0.00',
  `retailer_code` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `storeIdInvoicesIndex` (`store_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `invoice_date` (`invoice_date`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `name`, `details`, `store_id`, `invoice_date`, `supplier_id`, `supplier_name`, `dd_no`, `dd_amount`, `dd_purchase`, `created`, `modified`, `tax`, `invoice_value`, `special_margin`, `tcs_percent`, `tcs_value`, `prev_credit`, `credit_balance`, `mrp_rounding_off`, `retail_shop_excise_turnover_tax`, `special_excise_cess`, `new_retailer_prof_tax`, `ap_issue_price`, `ap_cess`, `ap_addl_prev_fee`, `ap_retail_excise_tax`, `ap_spl_prev_fee`, `ap_icdc_value`, `ap_tcs`, `ap_challan_no`, `ap_dd_amount`, `ap_previous_cr`, `ap_cr_balance`, `retailer_code`) VALUES
(1, '55835', NULL, 3, '2025-09-22', NULL, '', NULL, 50000.00, 28278.00, '2025-09-22 20:19:37', '2025-09-22 20:27:42', 0.00, 27600.00, 0.00, NULL, 6.00, 8.00, 21730.00, 654.00, 8.00, 5.00, 5.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 0.00, 0.00, 0.00, ''),
(2, '2500656', NULL, 2, '2025-09-28', NULL, '', NULL, 0.00, 124800.00, '2025-09-28 15:23:31', '2025-09-28 15:23:50', 0.00, 124800.00, 0.00, NULL, 0.00, 0.00, -124800.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 0.00, 0.00, 0.00, ''),
(3, '2500', NULL, 7, '2025-10-11', NULL, '', NULL, 1000000.00, NULL, '2025-10-11 14:49:58', '2025-10-11 14:49:58', 0.00, NULL, NULL, NULL, 4566.00, 5252.00, NULL, 645.00, 65.00, 6888.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 0.00, 0.00, 0.00, ''),
(9, '25008598 - Siddhivinayaka Wines', NULL, 9, '2025-10-30', NULL, '', NULL, 1500000.00, 1499282.22, '2025-11-09 06:56:00', '2025-11-09 11:54:26', 0.00, 1104348.92, 0.00, NULL, 13187.00, 371.66, 1089.44, 103821.30, 110435.00, 167490.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 0.00, 0.00, 0.00, ''),
(10, '25008541 - Vijaya Durga Wines', NULL, 10, '2025-10-28', NULL, '', NULL, 0.00, 1001140.40, '2025-11-09 11:16:12', '2025-11-09 11:45:10', 0.00, 737053.00, 0.00, NULL, 8789.00, 1001220.71, 80.31, 68072.40, 73706.00, 113520.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, 0.00, 0.00, 0.00, '');

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

DROP TABLE IF EXISTS `leaves`;
CREATE TABLE IF NOT EXISTS `leaves` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `leave_type_id` bigint UNSIGNED NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `is_half_day` tinyint DEFAULT '0',
  `status` enum('pending','approved','rejected','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'pending',
  `reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `approved_by` int DEFAULT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leave_quotas`
--

DROP TABLE IF EXISTS `leave_quotas`;
CREATE TABLE IF NOT EXISTS `leave_quotas` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `leave_type_id` bigint UNSIGNED NOT NULL,
  `year` int NOT NULL,
  `total_days` decimal(4,2) DEFAULT '0.00',
  `used_days` decimal(4,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leave_types`
--

DROP TABLE IF EXISTS `leave_types`;
CREATE TABLE IF NOT EXISTS `leave_types` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `product_code` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `shortcut_key` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `active` tinyint DEFAULT '1',
  `sort` smallint DEFAULT '0',
  `measuring_unit_value` decimal(10,2) DEFAULT '0.00',
  `measuring_unit` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `box_buying_price` decimal(10,2) DEFAULT NULL,
  `box_selling_price` decimal(10,2) DEFAULT NULL,
  `box_qty` int UNSIGNED DEFAULT '1',
  `unit_buying_price` decimal(12,2) DEFAULT '0.00',
  `unit_selling_price` decimal(12,2) DEFAULT '0.00',
  `discount_percentage` decimal(12,2) DEFAULT '0.00',
  `discount_amount` decimal(12,2) DEFAULT '0.00',
  `special_margin` decimal(12,2) DEFAULT '0.00',
  `has_variants` tinyint DEFAULT '0',
  `inventory_tracking` tinyint DEFAULT '1',
  `product_category_id` bigint UNSIGNED NOT NULL,
  `brand_id` bigint UNSIGNED DEFAULT NULL,
  `store_id` bigint UNSIGNED NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `group_product_id` bigint UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `store_id_name` (`store_id`,`name`),
  KEY `group_product_id` (`group_product_id`),
  KEY `product_category_id_store_id` (`product_category_id`,`store_id`),
  KEY `name` (`name`),
  KEY `brand_id` (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `product_code`, `shortcut_key`, `active`, `sort`, `measuring_unit_value`, `measuring_unit`, `box_buying_price`, `box_selling_price`, `box_qty`, `unit_buying_price`, `unit_selling_price`, `discount_percentage`, `discount_amount`, `special_margin`, `has_variants`, `inventory_tracking`, `product_category_id`, `brand_id`, `store_id`, `created`, `modified`, `group_product_id`) VALUES
(1, 'Blenders P', '5002', NULL, 1, NULL, 375.00, 'ml', 4800.00, NULL, 24, NULL, 250.00, 0.00, 0.00, 0.00, 0, 1, 1, 1, 2, '2025-09-17 13:07:40', '2025-09-17 13:07:40', 6),
(2, 'Blenders Q', '5001', NULL, 1, NULL, 750.00, 'ml', 4800.00, NULL, 12, NULL, 500.00, 0.00, 0.00, 0.00, 0, 1, 1, 1, 2, '2025-09-17 13:07:40', '2025-09-17 13:07:40', 5),
(3, 'Haywards - 330ml', '2002', NULL, 1, NULL, 330.00, 'ml', 2400.00, NULL, 24, NULL, 140.00, 0.00, 0.00, 0.00, 0, 1, 2, 2, 2, '2025-09-17 13:07:40', '2025-09-17 13:07:40', 4),
(4, 'Haywards - 650ml', '2001', NULL, 1, NULL, 650.00, 'ml', 2400.00, NULL, 12, NULL, 275.00, 0.00, 0.00, 0.00, 0, 1, 2, 2, 2, '2025-09-17 13:07:40', '2025-09-17 13:07:40', 3),
(5, 'KF - 330ml', '1002', NULL, 1, NULL, 330.00, 'ml', 2400.00, NULL, 24, NULL, 125.00, 0.00, 0.00, 0.00, 0, 1, 2, 3, 2, '2025-09-17 13:07:40', '2025-09-17 13:07:40', 2),
(6, 'KF - 650ml', '1001', NULL, 1, NULL, 650.00, 'ml', 2400.00, NULL, 12, NULL, 250.00, 0.00, 0.00, 0.00, 0, 1, 2, 3, 2, '2025-09-17 13:07:40', '2025-09-17 13:07:40', 1),
(7, 'Blenders Q', '5001', NULL, 1, NULL, 750.00, 'ml', 4800.00, NULL, 12, NULL, 500.00, 0.00, 0.00, 0.00, 0, 1, 3, 4, 3, '2025-09-22 20:18:27', '2025-09-22 20:18:27', 5),
(8, 'Haywards - 650ml', '2001', NULL, 1, NULL, 650.00, 'ml', 2400.00, NULL, 12, NULL, 275.00, 0.00, 0.00, 0.00, 0, 1, 12, 25, 3, '2025-09-22 20:18:27', '2025-09-22 20:18:27', 3),
(9, 'KF - 330ml', '1002', NULL, 1, NULL, 330.00, 'ml', 2400.00, NULL, 24, NULL, 125.00, 0.00, 0.00, 0.00, 0, 1, 12, 6, 3, '2025-09-22 20:18:27', '2025-09-22 20:18:27', 2),
(10, 'KF - 650ml', '1001', NULL, 1, NULL, 650.00, 'ml', 2400.00, NULL, 12, NULL, 250.00, 0.00, 0.00, 0.00, 0, 1, 12, 26, 3, '2025-09-22 20:18:27', '2025-09-22 20:18:27', 1),
(11, 'M H W - Q', '5100', NULL, 1, NULL, 750.00, 'ml', 3600.00, NULL, 12, NULL, 350.00, 0.00, 0.00, 0.00, 0, 1, 3, 27, 3, '2025-09-22 20:18:27', '2025-09-22 20:18:27', 8),
(12, 'Royal Stag N', '5200', NULL, 1, NULL, 180.00, 'ml', 4800.00, NULL, 48, NULL, 125.00, 0.00, 0.00, 0.00, 0, 1, 3, 8, 3, '2025-09-22 20:18:27', '2025-09-22 20:18:27', 10),
(13, 'Blenders N', '5003', NULL, 1, NULL, 180.00, 'ml', 4800.00, NULL, 48, NULL, 125.00, 0.00, 0.00, 0.00, 0, 1, 5, 9, 4, '2025-09-22 20:22:59', '2025-09-22 20:22:59', 7),
(14, 'Blenders P', '5002', NULL, 1, NULL, 375.00, 'ml', 4800.00, NULL, 24, NULL, 250.00, 0.00, 0.00, 0.00, 0, 1, 5, 9, 4, '2025-09-22 20:22:59', '2025-09-22 20:22:59', 6),
(15, 'Blenders Q', '5001', NULL, 1, NULL, 750.00, 'ml', 4800.00, NULL, 12, NULL, 500.00, 0.00, 0.00, 0.00, 0, 1, 5, 9, 4, '2025-09-22 20:22:59', '2025-09-22 20:22:59', 5),
(16, 'Brand-X D', '10000', NULL, 1, NULL, 90.00, 'ml', 9600.00, NULL, 96, NULL, 120.00, 0.00, 0.00, 0.00, 0, 1, 6, 28, 4, '2025-09-22 20:22:59', '2025-09-22 20:22:59', 11),
(17, 'Haywards - 330ml', '2002', NULL, 1, NULL, 330.00, 'ml', 2400.00, NULL, 24, NULL, 140.00, 0.00, 0.00, 0.00, 0, 1, 7, 12, 4, '2025-09-22 20:22:59', '2025-09-22 20:22:59', 4),
(18, 'Haywards - 650ml', '2001', NULL, 1, NULL, 650.00, 'ml', 2400.00, NULL, 12, NULL, 275.00, 0.00, 0.00, 0.00, 0, 1, 7, 15, 4, '2025-09-22 20:22:59', '2025-09-22 20:22:59', 3),
(19, 'KF - 330ml', '1002', NULL, 1, NULL, 330.00, 'ml', 2400.00, NULL, 24, NULL, 125.00, 0.00, 0.00, 0.00, 0, 1, 7, 13, 4, '2025-09-22 20:22:59', '2025-09-22 20:22:59', 2),
(20, 'KF - 650ml', '1001', NULL, 1, NULL, 650.00, 'ml', 2400.00, NULL, 12, NULL, 250.00, 0.00, 0.00, 0.00, 0, 1, 7, 16, 4, '2025-09-22 20:22:59', '2025-09-22 20:22:59', 1),
(21, 'M H W - P', '5101', NULL, 1, NULL, 375.00, 'ml', 3600.00, NULL, 24, NULL, 175.00, 0.00, 0.00, 0.00, 0, 1, 5, 14, 4, '2025-09-22 20:22:59', '2025-09-22 20:22:59', 9),
(22, 'M H W - Q', '5100', NULL, 1, NULL, 750.00, 'ml', 3600.00, NULL, 12, NULL, 350.00, 0.00, 0.00, 0.00, 0, 1, 5, 17, 4, '2025-09-22 20:22:59', '2025-09-22 20:22:59', 8),
(23, 'Royal Stag N', '5200', NULL, 1, NULL, 180.00, 'ml', 4800.00, NULL, 48, NULL, 125.00, 0.00, 0.00, 0.00, 0, 1, 5, 29, 4, '2025-09-22 20:22:59', '2025-09-22 20:22:59', 10),
(24, 'Blenders N', '5003', NULL, 1, NULL, 180.00, 'ml', 4800.00, NULL, 48, NULL, 125.00, 0.00, 0.00, 0.00, 0, 1, 8, 18, 5, '2025-09-22 20:25:40', '2025-09-22 20:25:40', 7),
(25, 'Blenders P', '5002', NULL, 1, NULL, 375.00, 'ml', 4800.00, NULL, 24, NULL, 250.00, 0.00, 0.00, 0.00, 0, 1, 8, 18, 5, '2025-09-22 20:25:40', '2025-09-22 20:25:40', 6),
(26, 'Blenders Q', '5001', NULL, 1, NULL, 750.00, 'ml', 4800.00, NULL, 12, NULL, 500.00, 0.00, 0.00, 0.00, 0, 1, 8, 18, 5, '2025-09-22 20:25:40', '2025-09-22 20:25:40', 5),
(27, 'Brand-X D', '10000', NULL, 1, NULL, 90.00, 'ml', 9600.00, NULL, 96, NULL, 120.00, 0.00, 0.00, 0.00, 0, 1, 9, 19, 5, '2025-09-22 20:25:40', '2025-09-22 20:25:40', 11),
(28, 'Haywards - 330ml', '2002', NULL, 1, NULL, 330.00, 'ml', 2400.00, NULL, 24, NULL, 140.00, 0.00, 0.00, 0.00, 0, 1, 10, 20, 5, '2025-09-22 20:25:40', '2025-09-22 20:25:40', 4),
(29, 'Haywards - 650ml', '2001', NULL, 1, NULL, 650.00, 'ml', 2400.00, NULL, 12, NULL, 275.00, 0.00, 0.00, 0.00, 0, 1, 10, 20, 5, '2025-09-22 20:25:40', '2025-09-22 20:25:40', 3),
(30, 'KF - 330ml', '1002', NULL, 1, NULL, 330.00, 'ml', 2400.00, NULL, 24, NULL, 125.00, 0.00, 0.00, 0.00, 0, 1, 10, 21, 5, '2025-09-22 20:25:40', '2025-09-22 20:25:40', 2),
(31, 'KF - 650ml', '1001', NULL, 1, NULL, 650.00, 'ml', 2400.00, NULL, 12, NULL, 250.00, 0.00, 0.00, 0.00, 0, 1, 10, 21, 5, '2025-09-22 20:25:40', '2025-09-22 20:25:40', 1),
(32, 'M H W - P', '5101', NULL, 1, NULL, 375.00, 'ml', 3600.00, NULL, 24, NULL, 175.00, 0.00, 0.00, 0.00, 0, 1, 8, 22, 5, '2025-09-22 20:25:40', '2025-09-22 20:25:40', 9),
(33, 'M H W - Q', '5100', NULL, 1, NULL, 750.00, 'ml', 3600.00, NULL, 12, NULL, 350.00, 0.00, 0.00, 0.00, 0, 1, 8, 22, 5, '2025-09-22 20:25:40', '2025-09-22 20:25:40', 8),
(34, 'Royal Stag N', '5200', NULL, 1, NULL, 180.00, 'ml', 4800.00, NULL, 48, NULL, 125.00, 0.00, 0.00, 0.00, 0, 1, 8, 23, 5, '2025-09-22 20:25:40', '2025-09-22 20:25:40', 10),
(35, 'Blenders N', '5003', NULL, 1, NULL, 180.00, 'ml', 4800.00, NULL, 48, NULL, 125.00, 0.00, 0.00, 0.00, 0, 1, 3, 4, 3, '2025-09-22 20:25:58', '2025-09-22 20:25:58', 7),
(36, 'Blenders P', '5002', NULL, 1, NULL, 375.00, 'ml', 4800.00, NULL, 24, NULL, 250.00, 0.00, 0.00, 0.00, 0, 1, 3, 4, 3, '2025-09-22 20:25:58', '2025-09-22 20:25:58', 6),
(37, 'Brand-X D', '10000', NULL, 1, NULL, 90.00, 'ml', 9600.00, NULL, 96, NULL, 120.00, 0.00, 0.00, 0.00, 0, 1, 11, 24, 3, '2025-09-22 20:18:27', '2025-09-22 20:18:27', 11),
(38, 'Haywards - 330ml', '2002', NULL, 1, NULL, 330.00, 'ml', 2400.00, NULL, 24, NULL, 140.00, 0.00, 0.00, 0.00, 0, 1, 4, 5, 3, '2025-09-22 20:18:27', '2025-09-22 20:18:27', 4),
(39, 'M H W - P', '5101', NULL, 1, NULL, 375.00, 'ml', 3600.00, NULL, 24, NULL, 175.00, 0.00, 0.00, 0.00, 0, 1, 3, 7, 3, '2025-09-22 20:18:27', '2025-09-22 20:18:27', 9),
(40, 'Blenders P', '5002', NULL, 1, NULL, 375.00, 'ml', 4800.00, NULL, 24, NULL, 250.00, 0.00, 0.00, 0.00, 0, 1, 13, 30, 1, '2025-09-22 20:28:22', '2025-09-22 20:28:22', 6),
(41, 'KF - 330ml', '1002', NULL, 1, NULL, 330.00, 'ml', 2400.00, NULL, 24, NULL, 125.00, 0.00, 0.00, 0.00, 0, 1, 14, 31, 1, '2025-09-22 20:31:27', '2025-09-22 20:31:27', 2),
(42, 'M H W - Q', '5100', NULL, 1, NULL, 750.00, 'ml', 3600.00, NULL, 12, NULL, 350.00, 0.00, 0.00, 0.00, 0, 1, 1, 32, 2, '2025-09-22 20:31:27', '2025-09-22 20:31:27', 8),
(43, 'M H W - Q', '5100', NULL, 1, NULL, 750.00, 'ml', 3600.00, NULL, 12, NULL, 350.00, 0.00, 0.00, 0.00, 0, 1, 13, 33, 1, '2025-09-22 20:31:27', '2025-09-22 20:31:27', 8),
(44, 'Royal Stag N', '5200', NULL, 1, NULL, 180.00, 'ml', 4800.00, NULL, 48, NULL, 125.00, 0.00, 0.00, 0.00, 0, 1, 1, 34, 2, '2025-09-22 20:31:27', '2025-09-22 20:31:27', 10),
(45, 'Royal Stag N', '5200', NULL, 1, NULL, 180.00, 'ml', 4800.00, NULL, 48, NULL, 125.00, 0.00, 0.00, 0.00, 0, 1, 13, 35, 1, '2025-09-22 20:31:27', '2025-09-22 20:31:27', 10),
(46, 'Haywards - 330ml', '2002', NULL, 1, NULL, 330.00, 'ml', 2400.00, NULL, 24, NULL, 140.00, 0.00, 0.00, 0.00, 0, 1, 14, 36, 1, '2025-09-28 15:24:40', '2025-09-28 15:24:40', 4),
(47, 'KF - 650ml', '1001', NULL, 1, NULL, 650.00, 'ml', 2400.00, NULL, 12, NULL, 250.00, 0.00, 0.00, 0.00, 0, 1, 14, 31, 1, '2025-09-28 15:24:40', '2025-09-28 15:24:40', 1),
(48, 'BLENDER - N', '', NULL, 1, NULL, 180.00, 'ml', 12004.00, NULL, 48, NULL, 350.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 18),
(49, 'BREEZER', '', NULL, 1, NULL, 275.00, 'ml', 2002.00, NULL, 24, NULL, 140.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 19),
(50, 'BUDWEISER-650ML', '', NULL, 1, NULL, 650.00, 'ml', 1801.00, NULL, 12, NULL, 210.00, 0.00, 0.00, 0.00, 0, 1, 15, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 12),
(51, 'CHEEP - N', '', NULL, 1, NULL, 180.00, 'ml', 3784.00, NULL, 48, NULL, 120.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 20),
(52, 'DK Double Kick', '', NULL, 1, NULL, 360.00, 'ml', 3784.00, NULL, 24, NULL, 110.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 21),
(53, 'IB - D', '', NULL, 1, NULL, 90.00, 'ml', 5608.00, NULL, 96, NULL, 95.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 22),
(54, 'IB - N', '', NULL, 1, NULL, 180.00, 'ml', 6004.00, NULL, 48, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 23),
(55, 'Iconiq - N', '', NULL, 1, NULL, 180.00, 'ml', 6004.00, NULL, 48, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 24),
(56, 'KF PREMIUM - 650ML', '', NULL, 1, NULL, 650.00, 'ml', 1501.00, NULL, 12, NULL, 190.00, 0.00, 0.00, 0.00, 0, 1, 15, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 13),
(57, 'KF STRONG - 650ML', '', NULL, 1, NULL, 650.00, 'ml', 1601.00, NULL, 12, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 15, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 14),
(58, 'KNOCKOUT-650ML', '', NULL, 1, NULL, 650.00, 'ml', 1601.00, NULL, 12, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 15, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 15),
(59, 'M H B - N', '', NULL, 1, NULL, 180.00, 'ml', 5604.00, NULL, 48, NULL, 190.00, 0.00, 0.00, 0.00, 0, 1, 18, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 16),
(60, 'M H B O - N', '', NULL, 1, NULL, 180.00, 'ml', 7204.00, NULL, 48, NULL, 230.00, 0.00, 0.00, 0.00, 0, 1, 18, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 17),
(61, 'MC LUXERY - D', '', NULL, 1, NULL, 90.00, 'ml', 5608.00, NULL, 96, NULL, 95.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 25),
(62, 'MC LUXURY - N', '', NULL, 1, NULL, 180.00, 'ml', 6004.00, NULL, 48, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 26),
(63, 'OC WHISKY - D', '', NULL, 1, NULL, 90.00, 'ml', 5608.00, NULL, 96, NULL, 95.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 27),
(64, 'OC WHISKY - N', '', NULL, 1, NULL, 180.00, 'ml', 5204.00, NULL, 48, NULL, 170.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 28),
(65, 'ROYAL GREEN -N', '', NULL, 1, NULL, 180.00, 'ml', 7204.00, NULL, 48, NULL, 220.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 29),
(66, 'ROYAL STAG - D', '', NULL, 1, NULL, 90.00, 'ml', 7208.00, NULL, 96, NULL, 115.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 30),
(67, 'ROYAL STAG - N', '', NULL, 1, NULL, 180.00, 'ml', 7204.00, NULL, 48, NULL, 230.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 31),
(68, 'SIGNATURE ULTRA - N', '', NULL, 1, NULL, 180.00, 'ml', 12004.00, NULL, 48, NULL, 350.00, 0.00, 0.00, 0.00, 0, 1, 17, NULL, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', 32),
(69, 'BLENDER - N', '', NULL, 1, NULL, 180.00, 'ml', 12004.00, NULL, 48, NULL, 350.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 18),
(70, 'BREEZER', '', NULL, 1, NULL, 275.00, 'ml', 2002.00, NULL, 24, NULL, 140.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 19),
(71, 'BUDWEISER-650ML', '', NULL, 1, NULL, 650.00, 'ml', 1801.00, NULL, 12, NULL, 210.00, 0.00, 0.00, 0.00, 0, 1, 19, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 12),
(72, 'CHEEP - N', '', NULL, 1, NULL, 180.00, 'ml', 3784.00, NULL, 48, NULL, 120.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 20),
(73, 'DK Double Kick', '', NULL, 1, NULL, 360.00, 'ml', 3784.00, NULL, 24, NULL, 110.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 21),
(74, 'IB - D', '', NULL, 1, NULL, 90.00, 'ml', 5608.00, NULL, 96, NULL, 95.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 22),
(75, 'IB - N', '', NULL, 1, NULL, 180.00, 'ml', 6004.00, NULL, 48, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 23),
(76, 'Iconiq - N', '', NULL, 1, NULL, 180.00, 'ml', 6004.00, NULL, 48, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 24),
(77, 'KF PREMIUM - 650ML', '', NULL, 1, NULL, 650.00, 'ml', 1501.00, NULL, 12, NULL, 190.00, 0.00, 0.00, 0.00, 0, 1, 19, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 13),
(78, 'KF STRONG - 650ML', '', NULL, 1, NULL, 650.00, 'ml', 1601.00, NULL, 12, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 19, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 14),
(79, 'KNOCKOUT-650ML', '', NULL, 1, NULL, 650.00, 'ml', 1601.00, NULL, 12, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 19, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 15),
(80, 'M H B - N', '', NULL, 1, NULL, 180.00, 'ml', 5604.00, NULL, 48, NULL, 190.00, 0.00, 0.00, 0.00, 0, 1, 22, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 16),
(81, 'M H B O - N', '', NULL, 1, NULL, 180.00, 'ml', 7204.00, NULL, 48, NULL, 230.00, 0.00, 0.00, 0.00, 0, 1, 22, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 17),
(82, 'MC LUXERY - D', '', NULL, 1, NULL, 90.00, 'ml', 5608.00, NULL, 96, NULL, 95.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 25),
(83, 'MC LUXURY - N', '', NULL, 1, NULL, 180.00, 'ml', 6004.00, NULL, 48, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 26),
(84, 'OC WHISKY - D', '', NULL, 1, NULL, 90.00, 'ml', 5608.00, NULL, 96, NULL, 95.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 27),
(85, 'OC WHISKY - N', '', NULL, 1, NULL, 180.00, 'ml', 5204.00, NULL, 48, NULL, 170.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 28),
(86, 'ROYAL GREEN -N', '', NULL, 1, NULL, 180.00, 'ml', 7204.00, NULL, 48, NULL, 220.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 29),
(87, 'ROYAL STAG - D', '', NULL, 1, NULL, 90.00, 'ml', 7208.00, NULL, 96, NULL, 115.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 30),
(88, 'ROYAL STAG - N', '', NULL, 1, NULL, 180.00, 'ml', 7204.00, NULL, 48, NULL, 230.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 31),
(89, 'SIGNATURE ULTRA - N', '', NULL, 1, NULL, 180.00, 'ml', 12004.00, NULL, 48, NULL, 350.00, 0.00, 0.00, 0.00, 0, 1, 21, NULL, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', 32),
(90, 'BLENDER - N', '', NULL, 1, NULL, 180.00, 'ml', 12004.00, NULL, 48, NULL, 350.00, 0.00, 0.00, 0.00, 0, 1, 23, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 39),
(91, 'BREEZER', '', NULL, 1, NULL, 275.00, 'ml', 2002.00, NULL, 24, NULL, 140.00, 0.00, 0.00, 0.00, 0, 1, 23, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 40),
(92, 'BUDWEISER-650ML', '', NULL, 1, NULL, 650.00, 'ml', 1801.00, NULL, 12, NULL, 210.00, 0.00, 0.00, 0.00, 0, 1, 24, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 33),
(93, 'CHEEP - N', '', NULL, 1, NULL, 180.00, 'ml', 3784.00, NULL, 48, NULL, 120.00, 0.00, 0.00, 0.00, 0, 1, 23, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 41),
(94, 'DK Double Kick', '', NULL, 1, NULL, 360.00, 'ml', 3784.00, NULL, 24, NULL, 110.00, 0.00, 0.00, 0.00, 0, 1, 25, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 42),
(95, 'IB - D', '', NULL, 1, NULL, 90.00, 'ml', 5608.00, NULL, 96, NULL, 95.00, 0.00, 0.00, 0.00, 0, 1, 25, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 43),
(96, 'IB - N', '', NULL, 1, NULL, 180.00, 'ml', 6004.00, NULL, 48, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 25, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 44),
(97, 'Iconiq - N', '', NULL, 1, NULL, 180.00, 'ml', 6004.00, NULL, 48, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 25, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 45),
(98, 'KF PREMIUM - 650ML', '', NULL, 1, NULL, 650.00, 'ml', 1501.00, NULL, 12, NULL, 190.00, 0.00, 0.00, 0.00, 0, 1, 23, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 34),
(99, 'KF STRONG - 650ML', '', NULL, 1, NULL, 650.00, 'ml', 1601.00, NULL, 12, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 23, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 35),
(100, 'KNOCKOUT-650ML', '', NULL, 1, NULL, 650.00, 'ml', 1601.00, NULL, 12, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 23, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 36),
(101, 'M H B - N', '', NULL, 1, NULL, 180.00, 'ml', 5604.00, NULL, 48, NULL, 190.00, 0.00, 0.00, 0.00, 0, 1, 26, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 37),
(102, 'M H B O - N', '', NULL, 1, NULL, 180.00, 'ml', 7204.00, NULL, 48, NULL, 230.00, 0.00, 0.00, 0.00, 0, 1, 26, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 38),
(103, 'MC LUXERY - D', '', NULL, 1, NULL, 90.00, 'ml', 5608.00, NULL, 96, NULL, 95.00, 0.00, 0.00, 0.00, 0, 1, 25, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 46),
(104, 'MC LUXURY - N', '', NULL, 1, NULL, 180.00, 'ml', 6004.00, NULL, 48, NULL, 200.00, 0.00, 0.00, 0.00, 0, 1, 25, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 47),
(105, 'OC WHISKY - D', '', NULL, 1, NULL, 90.00, 'ml', 5608.00, NULL, 96, NULL, 95.00, 0.00, 0.00, 0.00, 0, 1, 25, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 48),
(106, 'OC WHISKY - N', '', NULL, 1, NULL, 180.00, 'ml', 5204.00, NULL, 48, NULL, 170.00, 0.00, 0.00, 0.00, 0, 1, 25, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 49),
(107, 'ROYAL GREEN -N', '', NULL, 1, NULL, 180.00, 'ml', 7204.00, NULL, 48, NULL, 220.00, 0.00, 0.00, 0.00, 0, 1, 25, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 50),
(108, 'ROYAL STAG - D', '', NULL, 1, NULL, 90.00, 'ml', 7208.00, NULL, 96, NULL, 115.00, 0.00, 0.00, 0.00, 0, 1, 25, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 51),
(109, 'ROYAL STAG - N', '', NULL, 1, NULL, 180.00, 'ml', 7204.00, NULL, 48, NULL, 230.00, 0.00, 0.00, 0.00, 0, 1, 25, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 52),
(110, 'SIGNATURE ULTRA - N', '', NULL, 1, NULL, 180.00, 'ml', 12004.00, NULL, 48, NULL, 350.00, 0.00, 0.00, 0.00, 0, 1, 25, NULL, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', 53);

-- --------------------------------------------------------

--
-- Stand-in structure for view `product_breakage_report`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `product_breakage_report`;
CREATE TABLE IF NOT EXISTS `product_breakage_report` (
`breakage_amount` decimal(34,2)
,`breakage_qty` decimal(32,0)
,`id` bigint unsigned
,`product_category_id` bigint unsigned
,`product_name` varchar(255)
,`store_id` bigint unsigned
);

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

DROP TABLE IF EXISTS `product_categories`;
CREATE TABLE IF NOT EXISTS `product_categories` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_product_category_id` bigint DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `active` tinyint DEFAULT '1',
  `store_id` bigint UNSIGNED NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `tag` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `parent_id` bigint UNSIGNED DEFAULT '0',
  `type` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `active` (`active`),
  KEY `name` (`name`),
  KEY `store_id_group_product_category_id` (`store_id`,`group_product_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`id`, `group_product_category_id`, `name`, `active`, `store_id`, `created`, `modified`, `tag`, `parent_id`, `type`) VALUES
(1, 1, 'Whisky', 1, 2, '2025-09-17 13:07:40', '2025-09-22 20:31:27', 'IML', 0, NULL),
(2, 3, 'Beer', 1, 2, '2025-09-17 13:07:40', '2025-09-17 13:07:40', 'IML', 0, NULL),
(3, 1, 'Whisky', 1, 3, '2025-09-22 20:18:27', '2025-09-22 20:25:58', 'IML', 0, NULL),
(4, 2, 'Beer', 1, 3, '2025-09-22 20:25:58', '2025-09-22 20:25:58', 'IML', 0, NULL),
(5, 1, 'Whisky', 1, 4, '2025-09-22 20:22:59', '2025-09-22 20:26:08', 'IML', 0, NULL),
(6, 2, 'Wine', 1, 4, '2025-09-22 20:22:59', '2025-09-22 20:26:08', 'BEER', 0, NULL),
(7, 3, 'Beer', 1, 4, '2025-09-22 20:22:59', '2025-09-22 20:26:08', 'IML', 0, NULL),
(8, 1, 'Whisky', 1, 5, '2025-09-22 20:25:40', '2025-09-22 20:25:41', 'IML', 0, NULL),
(9, 2, 'Wine', 1, 5, '2025-09-22 20:25:41', '2025-09-22 20:25:41', 'BEER', 0, NULL),
(10, 3, 'Beer', 1, 5, '2025-09-22 20:25:41', '2025-09-22 20:25:41', 'IML', 0, NULL),
(11, 2, 'Wine', 1, 3, '2025-09-22 20:25:58', '2025-09-22 20:25:58', 'BEER', 0, NULL),
(12, 3, 'Beer', 1, 3, '2025-09-22 20:25:58', '2025-09-22 20:25:58', 'IML', 0, NULL),
(13, 1, 'Whisky', 1, 1, '2025-09-22 20:28:22', '2025-09-22 20:31:27', 'IML', 0, NULL),
(14, 3, 'Beer', 1, 1, '2025-09-22 20:31:27', '2025-09-28 15:24:40', 'IML', 0, NULL),
(15, 4, 'BEER', 1, 9, '2025-10-22 19:21:23', '2025-11-09 06:50:33', NULL, 0, NULL),
(16, 4, 'BEER', 1, 9, '2025-10-22 19:21:23', '2025-10-22 19:21:23', NULL, 0, NULL),
(17, 6, 'Whisky', 1, 9, '2025-10-22 19:21:23', '2025-11-09 06:50:33', NULL, 0, NULL),
(18, 5, 'Brandy', 1, 9, '2025-10-22 19:21:23', '2025-11-09 06:50:33', NULL, 0, NULL),
(19, 4, 'BEER', 1, 8, '2025-10-23 07:30:51', '2025-11-07 20:15:05', NULL, 0, NULL),
(20, 4, 'BEER', 1, 8, '2025-10-23 07:30:51', '2025-10-23 07:30:51', NULL, 0, NULL),
(21, 6, 'Whisky', 1, 8, '2025-10-23 07:30:51', '2025-11-07 20:15:05', NULL, 0, NULL),
(22, 5, 'Brandy', 1, 8, '2025-10-23 07:30:51', '2025-11-07 20:15:05', NULL, 0, NULL),
(23, 7, 'BEER', 1, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', NULL, 0, NULL),
(24, 7, 'BEER', 1, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', NULL, 0, NULL),
(25, 9, 'Whisky', 1, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', NULL, 0, NULL),
(26, 8, 'Brandy', 1, 10, '2025-11-09 10:54:23', '2025-11-09 10:54:23', NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `product_purchase_report`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `product_purchase_report`;
CREATE TABLE IF NOT EXISTS `product_purchase_report` (
`id` bigint unsigned
,`product_category_id` bigint unsigned
,`product_name` varchar(255)
,`purchase_amount` decimal(34,2)
,`purchase_qty` decimal(32,0)
,`store_id` bigint unsigned
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `product_sale_report`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `product_sale_report`;
CREATE TABLE IF NOT EXISTS `product_sale_report` (
`id` bigint unsigned
,`product_category_id` bigint unsigned
,`product_name` varchar(255)
,`sale_amount` decimal(34,2)
,`sale_qty` decimal(32,0)
,`store_id` bigint unsigned
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `product_stock_report`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `product_stock_report`;
CREATE TABLE IF NOT EXISTS `product_stock_report` (
`balance_qty` decimal(36,0)
,`breakage_amount` decimal(34,2)
,`breakage_qty` decimal(32,0)
,`category_id` bigint unsigned
,`category_name` varchar(255)
,`product_id` bigint unsigned
,`product_name` varchar(255)
,`profit_amount` decimal(47,2)
,`purchase_amount` decimal(34,2)
,`purchase_qty` decimal(32,0)
,`sale_amount` decimal(34,2)
,`sale_qty` decimal(32,0)
,`stock_transfer_in_amount` decimal(41,0)
,`stock_transfer_in_qty` decimal(32,0)
,`stock_transfer_out_amount` decimal(41,0)
,`stock_transfer_out_qty` decimal(32,0)
,`store_id` bigint unsigned
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `product_stock_transfer_in_report`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `product_stock_transfer_in_report`;
CREATE TABLE IF NOT EXISTS `product_stock_transfer_in_report` (
`id` bigint unsigned
,`product_category_id` bigint unsigned
,`product_name` varchar(255)
,`stock_transfer_in_qty` decimal(32,0)
,`store_id` bigint unsigned
,`total_amount` decimal(41,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `product_stock_transfer_out_report`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `product_stock_transfer_out_report`;
CREATE TABLE IF NOT EXISTS `product_stock_transfer_out_report` (
`id` bigint unsigned
,`product_category_id` bigint unsigned
,`product_name` varchar(255)
,`stock_transfer_out_qty` decimal(32,0)
,`store_id` bigint unsigned
,`total_amount` decimal(41,0)
);

-- --------------------------------------------------------

--
-- Table structure for table `product_variants`
--

DROP TABLE IF EXISTS `product_variants`;
CREATE TABLE IF NOT EXISTS `product_variants` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_product_variant_id` bigint UNSIGNED NOT NULL,
  `shortcut_key` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `product_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `store_id` bigint UNSIGNED NOT NULL,
  `active` tinyint DEFAULT '1',
  `sort` smallint DEFAULT '0',
  `measuring_unit_value` decimal(12,2) DEFAULT '0.00',
  `measuring_unit` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `unit_selling_price` decimal(12,2) DEFAULT '0.00',
  `discount_percentage` decimal(12,2) DEFAULT '0.00',
  `discount_amount` decimal(12,2) DEFAULT '0.00',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id_store_id` (`product_id`,`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `public_holidays`
--

DROP TABLE IF EXISTS `public_holidays`;
CREATE TABLE IF NOT EXISTS `public_holidays` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
CREATE TABLE IF NOT EXISTS `purchases` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_code` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `product_category_id` bigint UNSIGNED NOT NULL,
  `store_id` bigint UNSIGNED NOT NULL,
  `invoice_id` bigint DEFAULT NULL,
  `special_margin` decimal(10,2) DEFAULT '0.00',
  `box_buying_price` decimal(12,2) DEFAULT NULL,
  `box_qty` int UNSIGNED DEFAULT NULL,
  `total_special_margin` decimal(10,2) DEFAULT '0.00',
  `total_amount` decimal(12,2) DEFAULT NULL,
  `units_in_box` int DEFAULT NULL,
  `unit_price` decimal(12,2) DEFAULT NULL,
  `total_units` int UNSIGNED DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `product_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `category_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `store_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `invoice_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `from_mobile_app` tinyint UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `invoiceIdPurchasesIndex` (`invoice_id`),
  KEY `product_category_id` (`product_category_id`),
  KEY `store_id_product_id` (`store_id`,`product_id`),
  KEY `store_id_purchase_date` (`store_id`,`purchase_date`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`id`, `product_code`, `product_id`, `product_category_id`, `store_id`, `invoice_id`, `special_margin`, `box_buying_price`, `box_qty`, `total_special_margin`, `total_amount`, `units_in_box`, `unit_price`, `total_units`, `purchase_date`, `product_name`, `category_name`, `store_name`, `invoice_name`, `created`, `modified`, `from_mobile_app`) VALUES
(1, '5001', 7, 3, 3, 1, 0.00, 4800.00, 1, 0.00, 4800.00, 12, 400.00, 12, '2025-09-22', 'Blenders Q', 'Whisky', 'Store B', '55835', '2025-09-22 20:19:41', '2025-09-22 20:19:41', 0),
(2, '1002', 9, 4, 3, 1, 0.00, 2400.00, 1, 0.00, 2400.00, 24, 100.00, 24, '2025-09-22', 'KF - 330ml', 'Beer', 'Store B', '55835', '2025-09-22 20:20:18', '2025-09-22 20:20:18', 0),
(3, '5100', 11, 3, 3, 1, 0.00, 3600.00, 1, 0.00, 3600.00, 12, 300.00, 12, '2025-09-22', 'M H W - Q', 'Whisky', 'Store B', '55835', '2025-09-22 20:20:21', '2025-09-22 20:20:21', 0),
(4, '5001', 7, 3, 3, 1, 0.00, 4800.00, 1, 0.00, 4800.00, 12, 400.00, 12, '2025-09-22', 'Blenders Q', 'Whisky', 'Store B', '55835', '2025-09-22 20:20:24', '2025-09-22 20:20:24', 0),
(5, '5200', 12, 3, 3, 1, 0.00, 4800.00, 1, 0.00, 4800.00, 48, 100.00, 48, '2025-09-22', 'Royal Stag N', 'Whisky', 'Store B', '55835', '2025-09-22 20:20:31', '2025-09-22 20:20:31', 0),
(6, '1002', 9, 4, 3, 1, 0.00, 2400.00, 1, 0.00, 2400.00, 24, 100.00, 24, '2025-09-22', 'KF - 330ml', 'Beer', 'Store B', '55835', '2025-09-22 20:20:34', '2025-09-22 20:20:34', 0),
(7, '5002', 36, 3, 3, 1, 0.00, 4800.00, 1, 0.00, 4800.00, 24, 200.00, 24, '2025-09-22', 'Blenders P', 'Whisky', 'Store B', '55835', '2025-09-22 20:27:42', '2025-09-22 20:27:42', 0),
(8, '5002', 1, 1, 2, 2, 0.00, 4800.00, 5, 0.00, 24000.00, 24, 200.00, 120, '2025-09-28', 'Blenders P', 'Whisky', 'Store A', '2500656', '2025-09-28 15:23:34', '2025-09-28 15:23:34', 0),
(9, '2002', 3, 2, 2, 2, 0.00, 2400.00, 2, 0.00, 4800.00, 24, 100.00, 48, '2025-09-28', 'Haywards - 330ml', 'Beer', 'Store A', '2500656', '2025-09-28 15:23:39', '2025-09-28 15:23:39', 0),
(10, '1001', 6, 2, 2, 2, 0.00, 2400.00, 10, 0.00, 24000.00, 12, 200.00, 120, '2025-09-28', 'KF - 650ml', 'Beer', 'Store A', '2500656', '2025-09-28 15:23:44', '2025-09-28 15:23:44', 0),
(11, '5200', 44, 1, 2, 2, 0.00, 4800.00, 15, 0.00, 72000.00, 48, 100.00, 720, '2025-09-28', 'Royal Stag N', 'Whisky', 'Store A', '2500656', '2025-09-28 15:23:50', '2025-09-28 15:23:50', 0),
(12, '5001', 2, 1, 2, NULL, 0.00, NULL, NULL, 0.00, 22000.00, NULL, 400.00, 55, '2025-10-11', 'Blenders Q', 'Whisky', 'Store A', NULL, '2025-10-11 14:51:03', '2025-10-11 14:51:03', 0),
(38, '', 89, 21, 8, NULL, 0.00, NULL, NULL, 0.00, 10253.28, NULL, 250.08, 41, '2025-10-09', 'SIGNATURE ULTRA - N', 'Whisky', 'Gngwar', NULL, '2025-10-23 18:59:19', '2025-10-23 18:59:19', 0),
(39, '', 69, 19, 8, NULL, 0.00, NULL, NULL, 0.00, 8502.72, NULL, 250.08, 34, '2025-10-09', 'BLENDER - N', 'BEER', 'Gngwar', NULL, '2025-10-23 19:02:19', '2025-10-23 19:02:19', 0),
(40, '', 80, 22, 8, NULL, 0.00, NULL, NULL, 0.00, 9573.50, NULL, 116.75, 82, '2025-10-09', 'M H B - N', 'Brandy', 'Gngwar', NULL, '2025-10-23 19:03:12', '2025-10-23 19:03:12', 0),
(41, '', 81, 22, 8, NULL, 0.00, NULL, NULL, 0.00, 750.40, NULL, 150.08, 5, '2025-10-09', 'M H B O - N', 'Brandy', 'Gngwar', NULL, '2025-10-23 19:04:14', '2025-10-23 19:04:14', 0),
(42, '', 85, 21, 8, NULL, 0.00, NULL, NULL, 0.00, 237114.54, NULL, 108.42, 2187, '2025-10-09', 'OC WHISKY - N', 'Whisky', 'Gngwar', NULL, '2025-10-23 19:05:07', '2025-10-23 19:05:07', 0),
(43, '', 85, 21, 8, NULL, 0.00, NULL, NULL, 0.00, 236030.34, NULL, 108.42, 2177, '2025-10-09', 'OC WHISKY - N', 'Whisky', 'Gngwar', NULL, '2025-10-23 19:07:25', '2025-10-23 19:07:25', 0),
(52, '', 77, 19, 8, NULL, 0.00, NULL, NULL, 0.00, 2280.96, NULL, 190.08, 12, '2025-11-07', 'KF PREMIUM - 650ML', 'BEER', 'Gngwar', NULL, '2025-11-07 20:12:28', '2025-11-07 20:12:28', 0),
(53, '', 77, 19, 8, NULL, 0.00, NULL, NULL, 0.00, 2280.96, NULL, 190.08, 12, '2025-11-07', 'KF PREMIUM - 650ML', 'BEER', 'Gngwar', NULL, '2025-11-07 20:13:43', '2025-11-07 20:13:43', 0),
(54, '', 78, 19, 8, NULL, 0.00, NULL, NULL, 0.00, 2280.00, NULL, 190.00, 12, '2025-11-07', 'KF STRONG - 650ML', 'BEER', 'Gngwar', NULL, '2025-11-07 20:14:00', '2025-11-07 20:14:00', 0),
(55, '', 56, 15, 9, 9, 0.00, 1501.00, 16, 0.00, 24016.00, 12, 125.08, 192, '2025-10-30', 'KF PREMIUM - 650ML', 'BEER', 'Nykl Belt', '25008598 - Siddhivinayaka Wines', '2025-11-09 06:56:29', '2025-11-09 06:56:29', 0),
(56, '', 59, 18, 9, 9, 0.00, 5604.00, 2, 0.00, 11208.00, 48, 116.75, 96, '2025-10-30', 'M H B - N', 'Brandy', 'Nykl Belt', '25008598 - Siddhivinayaka Wines', '2025-11-09 06:56:47', '2025-11-09 06:56:47', 0),
(57, '', 62, 17, 9, 9, 0.00, 6004.00, 20, 0.00, 120080.00, 48, 125.08, 960, '2025-10-30', 'MC LUXURY - N', 'Whisky', 'Nykl Belt', '25008598 - Siddhivinayaka Wines', '2025-11-09 06:57:08', '2025-11-09 06:57:08', 0),
(58, '', 64, 17, 9, 9, 0.00, 5204.00, 60, 0.00, 312240.00, 48, 108.42, 2880, '2025-10-30', 'OC WHISKY - N', 'Whisky', 'Nykl Belt', '25008598 - Siddhivinayaka Wines', '2025-11-09 06:57:23', '2025-11-09 06:57:23', 0),
(59, '', 54, 17, 9, 9, 0.00, 6004.00, 29, 0.00, 179994.92, 48, 125.08, 1439, '2025-10-30', 'IB - N', 'Whisky', 'Nykl Belt', '25008598 - Siddhivinayaka Wines', '2025-11-09 06:57:40', '2025-11-09 06:57:40', 0),
(60, '', 67, 17, 9, 9, 0.00, 7204.00, 20, 0.00, 144080.00, 48, 150.08, 960, '2025-10-30', 'ROYAL STAG - N', 'Whisky', 'Nykl Belt', '25008598 - Siddhivinayaka Wines', '2025-11-09 06:57:54', '2025-11-09 06:57:54', 0),
(61, '', 51, 17, 9, 9, 0.00, 3784.00, 80, 0.00, 302720.00, 48, 78.83, 3840, '2025-10-30', 'CHEEP - N', 'Whisky', 'Nykl Belt', '25008598 - Siddhivinayaka Wines', '2025-11-09 06:58:11', '2025-11-09 06:58:11', 0),
(62, '', 49, 17, 9, 9, 0.00, 2002.00, 5, 0.00, 10010.00, 24, 83.42, 120, '2025-10-30', 'BREEZER', 'Whisky', 'Nykl Belt', '25008598 - Siddhivinayaka Wines', '2025-11-09 06:58:23', '2025-11-09 06:58:23', 0),
(63, '', 48, 17, 9, NULL, 0.00, NULL, NULL, 0.00, 19954.56, NULL, 350.08, 57, '2025-10-29', 'BLENDER - N', 'Whisky', 'Nykl Belt', NULL, '2025-11-09 07:17:14', '2025-11-09 07:17:14', 0),
(64, '', 68, 17, 9, NULL, 0.00, NULL, NULL, 0.00, 350.08, NULL, 350.08, 1, '2025-10-29', 'SIGNATURE ULTRA - N', 'Whisky', 'Nykl Belt', NULL, '2025-11-09 07:22:21', '2025-11-09 07:22:21', 0),
(65, '', 67, 17, 9, NULL, 0.00, NULL, NULL, 0.00, 126040.00, NULL, 230.00, 548, '2025-10-29', 'ROYAL STAG - N', 'Whisky', 'Nykl Belt', NULL, '2025-11-09 07:25:29', '2025-11-09 07:25:29', 0),
(66, '', 62, 17, 9, NULL, 0.00, NULL, NULL, 0.00, 135800.00, NULL, 200.00, 679, '2025-10-29', 'MC LUXURY - N', 'Whisky', 'Nykl Belt', NULL, '2025-11-09 07:28:06', '2025-11-09 07:28:06', 0),
(67, '', 59, 18, 9, NULL, 0.00, NULL, NULL, 0.00, 25650.00, NULL, 190.00, 135, '2025-10-29', 'M H B - N', 'Brandy', 'Nykl Belt', NULL, '2025-11-09 07:29:40', '2025-11-09 07:29:40', 0),
(68, '', 54, 17, 9, NULL, 0.00, NULL, NULL, 0.00, 239000.00, NULL, 200.00, 1195, '2025-10-29', 'IB - N', 'Whisky', 'Nykl Belt', NULL, '2025-11-09 07:30:15', '2025-11-09 07:30:15', 0),
(69, '', 64, 17, 9, NULL, 0.00, NULL, NULL, 0.00, 148410.00, NULL, 170.00, 873, '2025-10-29', 'OC WHISKY - N', 'Whisky', 'Nykl Belt', NULL, '2025-11-09 07:30:38', '2025-11-09 07:30:38', 0),
(70, '', 51, 17, 9, NULL, 0.00, NULL, NULL, 0.00, 48120.00, NULL, 120.00, 401, '2025-10-29', 'CHEEP - N', 'Whisky', 'Nykl Belt', NULL, '2025-11-09 07:31:12', '2025-11-09 07:31:12', 0),
(71, '', 49, 17, 9, NULL, 0.00, NULL, NULL, 0.00, 5040.00, NULL, 140.00, 36, '2025-10-29', 'BREEZER', 'Whisky', 'Nykl Belt', NULL, '2025-11-09 07:31:45', '2025-11-09 07:31:45', 0),
(72, '', 56, 15, 9, NULL, 0.00, NULL, NULL, 0.00, 1877820.00, NULL, 1190.00, 1578, '2025-10-29', 'KF PREMIUM - 650ML', 'BEER', 'Nykl Belt', NULL, '2025-11-09 07:32:15', '2025-11-09 07:32:15', 0),
(73, '', 98, 23, 10, 10, 0.00, 1501.00, 11, 0.00, 16511.00, 12, 125.08, 132, '2025-10-28', 'KF PREMIUM - 650ML', 'BEER', 'ZHB Gangwar', '25008541 - Vijaya Durga Wines', '2025-11-09 11:16:39', '2025-11-09 11:16:39', 0),
(74, '', 99, 23, 10, 10, 0.00, 1601.00, 30, 0.00, 48030.00, 12, 133.42, 360, '2025-10-28', 'KF STRONG - 650ML', 'BEER', 'ZHB Gangwar', '25008541 - Vijaya Durga Wines', '2025-11-09 11:16:52', '2025-11-09 11:16:52', 0),
(75, '', 101, 26, 10, 10, 0.00, 5604.00, 2, 0.00, 11208.00, 48, 116.75, 96, '2025-10-28', 'M H B - N', 'Brandy', 'ZHB Gangwar', '25008541 - Vijaya Durga Wines', '2025-11-09 11:17:25', '2025-11-09 11:17:25', 0),
(76, '', 104, 25, 10, 10, 0.00, 6004.00, 10, 0.00, 60040.00, 48, 125.08, 480, '2025-10-28', 'MC LUXURY - N', 'Whisky', 'ZHB Gangwar', '25008541 - Vijaya Durga Wines', '2025-11-09 11:17:43', '2025-11-09 11:17:43', 0),
(77, '', 106, 25, 10, 10, 0.00, 5204.00, 30, 0.00, 156120.00, 48, 108.42, 1440, '2025-10-28', 'OC WHISKY - N', 'Whisky', 'ZHB Gangwar', '25008541 - Vijaya Durga Wines', '2025-11-09 11:18:04', '2025-11-09 11:18:04', 0),
(78, '', 96, 25, 10, 10, 0.00, 6004.00, 30, 0.00, 180120.00, 48, 125.08, 1440, '2025-10-28', 'IB - N', 'Whisky', 'ZHB Gangwar', '25008541 - Vijaya Durga Wines', '2025-11-09 11:18:21', '2025-11-09 11:18:21', 0),
(79, '', 109, 25, 10, 10, 0.00, 7204.00, 10, 0.00, 72040.00, 48, 150.08, 480, '2025-10-28', 'ROYAL STAG - N', 'Whisky', 'ZHB Gangwar', '25008541 - Vijaya Durga Wines', '2025-11-09 11:18:40', '2025-11-09 11:18:40', 0),
(80, '', 93, 23, 10, 10, 0.00, 3784.00, 51, 0.00, 192984.00, 48, 78.83, 2448, '2025-10-28', 'CHEEP - N', 'BEER', 'ZHB Gangwar', '25008541 - Vijaya Durga Wines', '2025-11-09 11:20:41', '2025-11-09 11:20:41', 0),
(81, '', 110, 25, 10, NULL, 0.00, NULL, NULL, 0.00, 3500.00, NULL, 350.00, 10, '2025-10-27', 'SIGNATURE ULTRA - N', 'Whisky', 'ZHB Gangwar', NULL, '2025-11-09 11:24:41', '2025-11-09 11:24:41', 0),
(82, '', 90, 23, 10, NULL, 0.00, NULL, NULL, 0.00, 19600.00, NULL, 350.00, 56, '2025-10-27', 'BLENDER - N', 'BEER', 'ZHB Gangwar', NULL, '2025-11-09 11:25:18', '2025-11-09 11:25:18', 0),
(83, '', 109, 25, 10, NULL, 0.00, NULL, NULL, 0.00, 112930.00, NULL, 230.00, 491, '2025-10-27', 'ROYAL STAG - N', 'Whisky', 'ZHB Gangwar', NULL, '2025-11-09 11:25:42', '2025-11-09 11:25:42', 0),
(84, '', 96, 25, 10, NULL, 0.00, NULL, NULL, 0.00, 312000.00, NULL, 200.00, 1560, '2025-10-27', 'IB - N', 'Whisky', 'ZHB Gangwar', NULL, '2025-11-09 11:26:09', '2025-11-09 11:26:09', 0),
(85, '', 104, 25, 10, NULL, 0.00, NULL, NULL, 0.00, 187400.00, NULL, 200.00, 937, '2025-10-27', 'MC LUXURY - N', 'Whisky', 'ZHB Gangwar', NULL, '2025-11-09 11:26:37', '2025-11-09 11:26:37', 0),
(86, '', 102, 26, 10, NULL, 0.00, NULL, NULL, 0.00, 8360.00, NULL, 190.00, 44, '2025-10-27', 'M H B O - N', 'Brandy', 'ZHB Gangwar', NULL, '2025-11-09 11:31:07', '2025-11-09 11:31:07', 0),
(87, '', 106, 25, 10, NULL, 0.00, NULL, NULL, 0.00, 196010.00, NULL, 170.00, 1153, '2025-10-27', 'OC WHISKY - N', 'Whisky', 'ZHB Gangwar', NULL, '2025-11-09 11:31:41', '2025-11-09 11:31:41', 0),
(88, '', 93, 23, 10, NULL, 0.00, NULL, NULL, 0.00, 51240.00, NULL, 120.00, 427, '2025-10-27', 'CHEEP - N', 'BEER', 'ZHB Gangwar', NULL, '2025-11-09 11:32:09', '2025-11-09 11:32:09', 0),
(89, '', 91, 23, 10, NULL, 0.00, NULL, NULL, 0.00, 7560.00, NULL, 140.00, 54, '2025-10-27', 'BREEZER', 'BEER', 'ZHB Gangwar', NULL, '2025-11-09 11:32:30', '2025-11-09 11:32:30', 0),
(90, '', 98, 23, 10, NULL, 0.00, NULL, NULL, 0.00, 91960.00, NULL, 190.00, 484, '2025-10-27', 'KF PREMIUM - 650ML', 'BEER', 'ZHB Gangwar', NULL, '2025-11-09 11:32:55', '2025-11-09 11:32:55', 0),
(91, '', 101, 26, 10, NULL, 0.00, NULL, NULL, 0.00, 8360.00, NULL, 190.00, 44, '2025-10-27', 'M H B - N', 'Brandy', 'ZHB Gangwar', NULL, '2025-11-09 11:37:19', '2025-11-09 11:37:19', 0),
(92, '', 99, 23, 10, NULL, 0.00, NULL, NULL, 0.00, 96800.00, NULL, 200.00, 484, '2025-10-27', 'KF STRONG - 650ML', 'BEER', 'ZHB Gangwar', NULL, '2025-11-09 11:46:23', '2025-11-09 11:46:23', 0),
(93, '', 57, 15, 9, NULL, 0.00, NULL, NULL, 0.00, 2400.00, NULL, 200.00, 12, '2025-10-28', 'KF STRONG - 650ML', 'BEER', 'Nykl Belt', NULL, '2025-11-10 07:28:59', '2025-11-10 07:28:59', 0),
(94, '', 57, 15, 9, NULL, 0.00, NULL, NULL, 0.00, 36000.00, NULL, 200.00, 180, '2025-10-28', 'KF STRONG - 650ML', 'BEER', 'Nykl Belt', NULL, '2025-11-10 07:30:22', '2025-11-10 07:30:22', 0),
(95, '', 57, 15, 9, NULL, 0.00, NULL, NULL, 0.00, 217000.00, NULL, 200.00, 1085, '2025-11-30', 'KF STRONG - 650ML', 'BEER', 'Nykl Belt', NULL, '2025-11-10 07:48:45', '2025-11-10 07:48:45', 0),
(96, '', 57, 15, 9, NULL, 0.00, NULL, NULL, 0.00, 182200.00, NULL, 200.00, 911, '2025-11-01', 'KF STRONG - 650ML', 'BEER', 'Nykl Belt', NULL, '2025-11-10 08:20:12', '2025-11-10 08:20:12', 0);

-- --------------------------------------------------------

--
-- Table structure for table `salaries`
--

DROP TABLE IF EXISTS `salaries`;
CREATE TABLE IF NOT EXISTS `salaries` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id` bigint UNSIGNED NOT NULL,
  `employee_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_amount` decimal(10,2) DEFAULT NULL,
  `remarks` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `store_id` bigint UNSIGNED NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`),
  KEY `store_id` (`store_id`),
  KEY `payment_date` (`payment_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
CREATE TABLE IF NOT EXISTS `sales` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_code` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `product_variant_id` bigint DEFAULT NULL,
  `measuring_unit_value` decimal(12,2) DEFAULT '0.00',
  `measuring_unit` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `product_category_id` bigint UNSIGNED NOT NULL,
  `store_id` bigint UNSIGNED NOT NULL,
  `measuring_unit_price` decimal(12,2) DEFAULT '0.00',
  `unit_price` decimal(10,2) DEFAULT '0.00',
  `total_measuring_units` int DEFAULT NULL,
  `total_measuring_units_value` decimal(12,2) DEFAULT '0.00',
  `total_units` int DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT NULL,
  `sale_date` date DEFAULT NULL,
  `product_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `category_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `store_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `closing_stock_qty` decimal(12,3) DEFAULT NULL,
  `reference` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `from_mobile_app` tinyint UNSIGNED NOT NULL DEFAULT '0',
  `bill_id` bigint UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_category_id` (`product_category_id`),
  KEY `store_id_sale_date` (`store_id`,`sale_date`),
  KEY `store_id_product_id` (`store_id`,`product_id`),
  KEY `store_id_reference` (`store_id`,`reference`),
  KEY `created` (`created` DESC),
  KEY `product_variant_id` (`product_variant_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `product_code`, `product_id`, `product_variant_id`, `measuring_unit_value`, `measuring_unit`, `product_category_id`, `store_id`, `measuring_unit_price`, `unit_price`, `total_measuring_units`, `total_measuring_units_value`, `total_units`, `total_amount`, `sale_date`, `product_name`, `category_name`, `store_name`, `created`, `modified`, `closing_stock_qty`, `reference`, `from_mobile_app`, `bill_id`) VALUES
(1, '1002', 9, NULL, 0.00, NULL, 4, 3, 0.00, 125.00, NULL, 0.00, 13, 1625.00, '2025-09-22', 'KF - 330ml', 'Beer', 'Store B', '2025-09-22 20:20:40', '2025-09-22 20:20:40', 35.000, '#ClosingStock', 0, NULL),
(2, '5001', 7, NULL, 0.00, NULL, 3, 3, 0.00, 500.00, NULL, 0.00, 18, 9000.00, '2025-09-22', 'Blenders Q', 'Whisky', 'Store B', '2025-09-22 20:20:49', '2025-09-22 20:20:49', 6.000, '#ClosingStock', 0, NULL),
(3, '1002', 9, NULL, 0.00, NULL, 4, 3, 0.00, 125.00, NULL, 0.00, 30, 3750.00, '2025-09-22', 'KF - 330ml', 'Beer', 'Store B', '2025-09-22 20:21:13', '2025-09-22 20:21:13', 5.000, '#ClosingStock', 0, NULL),
(4, '5001', 7, NULL, 0.00, NULL, 3, 3, 0.00, 500.00, NULL, 0.00, 1, 500.00, '2025-09-21', 'Blenders Q', 'Whisky', 'Store B', '2025-09-22 20:21:26', '2025-09-22 20:21:26', NULL, NULL, 0, NULL),
(5, '5002', 14, NULL, 0.00, NULL, 5, 4, 0.00, 250.00, NULL, 0.00, 2, 500.00, '2025-09-22', 'Blenders P', 'Whisky', 'Store C', '2025-09-22 20:30:29', '2025-09-22 20:30:29', 1.000, '#ClosingStock', 0, NULL),
(6, '2002', 38, NULL, 0.00, NULL, 4, 3, 0.00, 140.00, NULL, 0.00, 8, 1120.00, '2025-09-28', 'Haywards - 330ml', 'Beer', 'Store B', '2025-09-28 15:25:01', '2025-09-28 15:25:01', 2.000, '#ClosingStock', 0, NULL),
(7, '5002', 36, NULL, 0.00, NULL, 3, 3, 0.00, 250.00, NULL, 0.00, 3, 750.00, '2025-09-28', 'Blenders P', 'Whisky', 'Store B', '2025-09-28 15:25:05', '2025-09-28 15:25:05', 10.000, '#ClosingStock', 0, NULL),
(8, '2002', 17, NULL, 0.00, NULL, 7, 4, 0.00, 140.00, NULL, 0.00, 1, 140.00, '2025-09-28', 'Haywards - 330ml', 'Beer', 'Store C', '2025-09-28 15:25:12', '2025-09-28 15:25:12', 1.000, '#ClosingStock', 0, NULL),
(9, '5002', 14, NULL, 0.00, NULL, 5, 4, 0.00, 250.00, NULL, 0.00, 9, 2250.00, '2025-09-28', 'Blenders P', 'Whisky', 'Store C', '2025-09-28 15:25:23', '2025-09-28 15:25:23', 5.000, '#ClosingStock', 0, NULL),
(10, '2002', 28, NULL, 0.00, NULL, 10, 5, 0.00, 140.00, NULL, 0.00, 3, 420.00, '2025-09-28', 'Haywards - 330ml', 'Beer', 'Store D', '2025-09-28 15:25:30', '2025-09-28 15:25:30', 3.000, '#ClosingStock', 0, NULL),
(11, '5200', 34, NULL, 0.00, NULL, 8, 5, 0.00, 125.00, NULL, 0.00, 8, 1000.00, '2025-09-28', 'Royal Stag N', 'Whisky', 'Store D', '2025-09-28 15:25:34', '2025-09-28 15:25:34', 55.000, '#ClosingStock', 0, NULL),
(12, '5200', 34, NULL, 0.00, NULL, 8, 5, 0.00, 125.00, NULL, 0.00, 1, 125.00, '2025-09-28', 'Royal Stag N', 'Whisky', 'Store D', '2025-09-28 15:25:42', '2025-09-28 15:25:42', NULL, NULL, 0, NULL),
(13, '2002', 28, NULL, 0.00, NULL, 10, 5, 0.00, 140.00, NULL, 0.00, 1, 140.00, '2025-09-28', 'Haywards - 330ml', 'Beer', 'Store D', '2025-09-28 15:25:49', '2025-09-28 15:25:49', NULL, NULL, 0, NULL),
(14, '2002', 3, NULL, 0.00, NULL, 2, 2, 0.00, 140.00, NULL, 0.00, 12, 1680.00, '2025-09-28', 'Haywards - 330ml', 'Beer', 'Store A', '2025-09-28 15:26:44', '2025-09-28 15:26:44', 10.000, '#ClosingStock', 0, NULL),
(15, '2002', 3, NULL, 0.00, NULL, 2, 2, 0.00, 140.00, NULL, 0.00, 8, 1120.00, '2025-10-11', 'Haywards - 330ml', 'Beer', 'Store A', '2025-10-11 14:50:33', '2025-10-11 14:50:33', 2.000, '#ClosingStock', 0, NULL),
(16, '2002', 3, NULL, 0.00, NULL, 2, 2, 0.00, 140.00, NULL, 0.00, 1, 140.00, '2025-10-11', 'Haywards - 330ml', 'Beer', 'Store A', '2025-10-11 14:50:40', '2025-10-11 14:50:40', NULL, NULL, 0, NULL),
(45, '', 67, NULL, 0.00, NULL, 17, 9, 0.00, 230.00, NULL, 0.00, 97, 22310.00, '2025-10-30', 'ROYAL STAG - N', 'Whisky', 'Nykl Belt', '2025-11-09 09:33:08', '2025-11-09 09:33:08', 1411.000, '#ClosingStock', 0, NULL),
(46, '', 62, NULL, 0.00, NULL, 17, 9, 0.00, 200.00, NULL, 0.00, 119, 23800.00, '2025-10-30', 'MC LUXURY - N', 'Whisky', 'Nykl Belt', '2025-11-09 09:33:21', '2025-11-09 09:33:21', 1520.000, '#ClosingStock', 0, NULL),
(47, '', 59, NULL, 0.00, NULL, 18, 9, 0.00, 190.00, NULL, 0.00, 1, 190.00, '2025-10-30', 'M H B - N', 'Brandy', 'Nykl Belt', '2025-11-09 09:33:41', '2025-11-09 09:33:41', 230.000, '#ClosingStock', 0, NULL),
(48, '', 54, NULL, 0.00, NULL, 17, 9, 0.00, 200.00, NULL, 0.00, 258, 51600.00, '2025-10-30', 'IB - N', 'Whisky', 'Nykl Belt', '2025-11-09 09:33:59', '2025-11-09 09:33:59', 2376.000, '#ClosingStock', 0, NULL),
(49, '', 109, NULL, 0.00, NULL, 25, 10, 0.00, 230.00, NULL, 0.00, 20, 4600.00, '2025-10-28', 'ROYAL STAG - N', 'Whisky', 'ZHB Gangwar', '2025-11-09 11:34:23', '2025-11-09 11:34:23', 951.000, '#ClosingStock', 0, NULL),
(50, '', 96, NULL, 0.00, NULL, 25, 10, 0.00, 200.00, NULL, 0.00, 86, 17200.00, '2025-10-28', 'IB - N', 'Whisky', 'ZHB Gangwar', '2025-11-09 11:34:38', '2025-11-09 11:34:38', 2914.000, '#ClosingStock', 0, NULL),
(51, '', 104, NULL, 0.00, NULL, 25, 10, 0.00, 200.00, NULL, 0.00, 58, 11600.00, '2025-10-28', 'MC LUXURY - N', 'Whisky', 'ZHB Gangwar', '2025-11-09 11:34:52', '2025-11-09 11:34:52', 1359.000, '#ClosingStock', 0, NULL),
(52, '', 106, NULL, 0.00, NULL, 25, 10, 0.00, 170.00, NULL, 0.00, 137, 23290.00, '2025-10-28', 'OC WHISKY - N', 'Whisky', 'ZHB Gangwar', '2025-11-09 11:37:57', '2025-11-09 11:37:57', 2456.000, '#ClosingStock', 0, NULL),
(53, '', 93, NULL, 0.00, NULL, 23, 10, 0.00, 120.00, NULL, 0.00, 239, 28680.00, '2025-10-28', 'CHEEP - N', 'BEER', 'ZHB Gangwar', '2025-11-09 11:38:12', '2025-11-09 11:38:12', 2636.000, '#ClosingStock', 0, NULL),
(54, '', 99, NULL, 0.00, NULL, 23, 10, 0.00, 200.00, NULL, 0.00, 14, 2800.00, '2025-10-28', 'KF STRONG - 650ML', 'BEER', 'ZHB Gangwar', '2025-11-09 11:47:48', '2025-11-09 11:47:48', 830.000, '#ClosingStock', 0, NULL),
(55, '', 64, NULL, 0.00, NULL, 17, 9, 0.00, 170.00, NULL, 0.00, 329, 55930.00, '2025-10-30', 'OC WHISKY - N', 'Whisky', 'Nykl Belt', '2025-11-09 11:59:05', '2025-11-09 11:59:05', 3424.000, '#ClosingStock', 0, NULL),
(56, '', 51, NULL, 0.00, NULL, 17, 9, 0.00, 120.00, NULL, 0.00, 320, 38400.00, '2025-10-30', 'CHEEP - N', 'Whisky', 'Nykl Belt', '2025-11-09 11:59:30', '2025-11-09 11:59:30', 3921.000, '#ClosingStock', 0, NULL),
(58, '', 62, NULL, 0.00, NULL, 17, 9, 0.00, 200.00, NULL, 0.00, 90, 18000.00, '2025-10-31', 'MC LUXURY - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:19:38', '2025-11-10 07:19:38', 1430.000, '#ClosingStock', 0, NULL),
(59, '', 59, NULL, 0.00, NULL, 18, 9, 0.00, 190.00, NULL, 0.00, 11, 2090.00, '2025-10-31', 'M H B - N', 'Brandy', 'Nykl Belt', '2025-11-10 07:20:10', '2025-11-10 07:20:10', 219.000, '#ClosingStock', 0, NULL),
(60, '', 54, NULL, 0.00, NULL, 17, 9, 0.00, 200.00, NULL, 0.00, 196, 39200.00, '2025-10-31', 'IB - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:20:21', '2025-11-10 07:20:21', 2180.000, '#ClosingStock', 0, NULL),
(61, '', 64, NULL, 0.00, NULL, 17, 9, 0.00, 170.00, NULL, 0.00, 236, 40120.00, '2025-10-31', 'OC WHISKY - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:20:37', '2025-11-10 07:20:37', 3188.000, '#ClosingStock', 0, NULL),
(62, '', 51, NULL, 0.00, NULL, 17, 9, 0.00, 120.00, NULL, 0.00, 336, 40320.00, '2025-10-31', 'CHEEP - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:20:50', '2025-11-10 07:20:50', 3585.000, '#ClosingStock', 0, NULL),
(63, '', 49, NULL, 0.00, NULL, 17, 9, 0.00, 140.00, NULL, 0.00, 5, 700.00, '2025-10-31', 'BREEZER', 'Whisky', 'Nykl Belt', '2025-11-10 07:21:01', '2025-11-10 07:21:01', 151.000, '#ClosingStock', 0, NULL),
(64, '', 57, NULL, 0.00, NULL, 15, 9, 0.00, 200.00, NULL, 0.00, 72, 14400.00, '2025-10-31', 'KF STRONG - 650ML', 'BEER', 'Nykl Belt', '2025-11-10 07:30:44', '2025-11-10 07:30:44', 120.000, '#ClosingStock', 0, NULL),
(66, '', 48, NULL, 0.00, NULL, 17, 9, 0.00, 350.00, NULL, 0.00, 4, 1400.00, '2025-11-01', 'BLENDER - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:38:58', '2025-11-10 07:38:58', 53.000, '#ClosingStock', 0, NULL),
(67, '', 68, NULL, 0.00, NULL, 17, 9, 0.00, 350.00, NULL, 0.00, 1, 350.00, '2025-11-01', 'SIGNATURE ULTRA - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:39:12', '2025-11-10 07:39:12', 0.000, '#ClosingStock', 0, NULL),
(68, '', 67, NULL, 0.00, NULL, 17, 9, 0.00, 230.00, NULL, 0.00, 88, 20240.00, '2025-10-31', 'ROYAL STAG - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:41:38', '2025-11-10 07:41:38', 1323.000, '#ClosingStock', 0, NULL),
(69, '', 67, NULL, 0.00, NULL, 17, 9, 0.00, 230.00, NULL, 0.00, 170, 39100.00, '2025-11-01', 'ROYAL STAG - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:42:21', '2025-11-10 07:42:21', 1153.000, '#ClosingStock', 0, NULL),
(70, '', 62, NULL, 0.00, NULL, 17, 9, 0.00, 200.00, NULL, 0.00, 223, 44600.00, '2025-11-01', 'MC LUXURY - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:42:34', '2025-11-10 07:42:34', 1207.000, '#ClosingStock', 0, NULL),
(71, '', 59, NULL, 0.00, NULL, 18, 9, 0.00, 190.00, NULL, 0.00, 38, 7220.00, '2025-11-01', 'M H B - N', 'Brandy', 'Nykl Belt', '2025-11-10 07:42:54', '2025-11-10 07:42:54', 181.000, '#ClosingStock', 0, NULL),
(72, '', 54, NULL, 0.00, NULL, 17, 9, 0.00, 200.00, NULL, 0.00, 386, 77200.00, '2025-11-01', 'IB - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:43:09', '2025-11-10 07:43:09', 1794.000, '#ClosingStock', 0, NULL),
(73, '', 64, NULL, 0.00, NULL, 17, 9, 0.00, 170.00, NULL, 0.00, 479, 81430.00, '2025-11-01', 'OC WHISKY - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:43:26', '2025-11-10 07:43:26', 2709.000, '#ClosingStock', 0, NULL),
(74, '', 51, NULL, 0.00, NULL, 17, 9, 0.00, 120.00, NULL, 0.00, 608, 72960.00, '2025-11-01', 'CHEEP - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:43:43', '2025-11-10 07:43:43', 2977.000, '#ClosingStock', 0, NULL),
(75, '', 49, NULL, 0.00, NULL, 17, 9, 0.00, 140.00, NULL, 0.00, 48, 6720.00, '2025-11-01', 'BREEZER', 'Whisky', 'Nykl Belt', '2025-11-10 07:43:52', '2025-11-10 07:43:52', 103.000, '#ClosingStock', 0, NULL),
(76, '', 57, NULL, 0.00, NULL, 15, 9, 0.00, 200.00, NULL, 0.00, 294, 58800.00, '2025-11-01', 'KF STRONG - 650ML', 'BEER', 'Nykl Belt', '2025-11-10 07:48:58', '2025-11-10 07:48:58', 911.000, '#ClosingStock', 0, NULL),
(78, '', 56, NULL, 0.00, NULL, 15, 9, 0.00, 190.00, NULL, 0.00, 1650, 313500.00, '2025-10-31', 'KF PREMIUM - 650ML', 'BEER', 'Nykl Belt', '2025-11-10 07:54:50', '2025-11-10 07:54:50', 120.000, '#ClosingStock', 0, NULL),
(79, '', 56, NULL, 0.00, NULL, 15, 9, 0.00, 190.00, NULL, 0.00, 36, 6840.00, '2025-11-01', 'KF PREMIUM - 650ML', 'BEER', 'Nykl Belt', '2025-11-10 07:55:13', '2025-11-10 07:55:13', 84.000, '#ClosingStock', 0, NULL),
(80, '', 48, NULL, 0.00, NULL, 17, 9, 0.00, 350.00, NULL, 0.00, 10, 3500.00, '2025-11-02', 'BLENDER - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:59:00', '2025-11-10 07:59:00', 43.000, '#ClosingStock', 0, NULL),
(81, '', 67, NULL, 0.00, NULL, 17, 9, 0.00, 230.00, NULL, 0.00, 179, 41170.00, '2025-11-02', 'ROYAL STAG - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:59:26', '2025-11-10 07:59:26', 974.000, '#ClosingStock', 0, NULL),
(82, '', 62, NULL, 0.00, NULL, 17, 9, 0.00, 200.00, NULL, 0.00, 134, 26800.00, '2025-11-02', 'MC LUXURY - N', 'Whisky', 'Nykl Belt', '2025-11-10 07:59:44', '2025-11-10 07:59:44', 1073.000, '#ClosingStock', 0, NULL),
(83, '', 59, NULL, 0.00, NULL, 18, 9, 0.00, 190.00, NULL, 0.00, 69, 13110.00, '2025-11-02', 'M H B - N', 'Brandy', 'Nykl Belt', '2025-11-10 08:00:24', '2025-11-10 08:00:24', 112.000, '#ClosingStock', 0, NULL),
(84, '', 54, NULL, 0.00, NULL, 17, 9, 0.00, 200.00, NULL, 0.00, 481, 96200.00, '2025-11-02', 'IB - N', 'Whisky', 'Nykl Belt', '2025-11-10 08:00:38', '2025-11-10 08:00:38', 1313.000, '#ClosingStock', 0, NULL),
(85, '', 64, NULL, 0.00, NULL, 17, 9, 0.00, 170.00, NULL, 0.00, 511, 86870.00, '2025-11-02', 'OC WHISKY - N', 'Whisky', 'Nykl Belt', '2025-11-10 08:00:54', '2025-11-10 08:00:54', 2198.000, '#ClosingStock', 0, NULL),
(86, '', 51, NULL, 0.00, NULL, 17, 9, 0.00, 120.00, NULL, 0.00, 789, 94680.00, '2025-11-02', 'CHEEP - N', 'Whisky', 'Nykl Belt', '2025-11-10 08:01:04', '2025-11-10 08:01:04', 2188.000, '#ClosingStock', 0, NULL),
(87, '', 56, NULL, 0.00, NULL, 15, 9, 0.00, 190.00, NULL, 0.00, 6, 1140.00, '2025-11-02', 'KF PREMIUM - 650ML', 'BEER', 'Nykl Belt', '2025-11-10 08:01:37', '2025-11-10 08:01:37', 78.000, '#ClosingStock', 0, NULL),
(89, '', 57, NULL, 0.00, NULL, 15, 9, 0.00, 200.00, NULL, 0.00, 268, 53600.00, '2025-11-02', 'KF STRONG - 650ML', 'BEER', 'Nykl Belt', '2025-11-10 08:35:35', '2025-11-10 08:35:35', 1554.000, '#ClosingStock', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stock_transfer_ins`
--

DROP TABLE IF EXISTS `stock_transfer_ins`;
CREATE TABLE IF NOT EXISTS `stock_transfer_ins` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `store_id` bigint UNSIGNED NOT NULL,
  `from_store_id` bigint UNSIGNED NOT NULL,
  `stock_transfer_out_id` bigint UNSIGNED NOT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `from_store_product_id` bigint UNSIGNED NOT NULL,
  `box_qty` int DEFAULT '0',
  `loose_units` int DEFAULT NULL,
  `total_units` int DEFAULT NULL,
  `total_amount` bigint DEFAULT '0',
  `transfer_in_date` date DEFAULT NULL,
  `from_mobile_app` tinyint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ProductIdStoreIdIndex` (`store_id`,`product_id`),
  KEY `from_store_id_from_store_product_id` (`from_store_id`,`from_store_product_id`),
  KEY `store_id_transfer_in_date` (`store_id`,`transfer_in_date`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_transfer_ins`
--

INSERT INTO `stock_transfer_ins` (`id`, `store_id`, `from_store_id`, `stock_transfer_out_id`, `product_id`, `from_store_product_id`, `box_qty`, `loose_units`, `total_units`, `total_amount`, `transfer_in_date`, `from_mobile_app`, `created`, `modified`) VALUES
(1, 2, 3, 1, 1, 36, 0, 2, 2, 0, '2025-09-22', NULL, '2025-09-22 20:28:22', '2025-09-22 20:28:22'),
(2, 4, 3, 2, 14, 36, 0, 3, 3, 0, '2025-09-22', NULL, '2025-09-22 20:28:22', '2025-09-22 20:28:22'),
(3, 5, 3, 3, 25, 36, 0, 4, 4, 0, '2025-09-22', NULL, '2025-09-22 20:28:22', '2025-09-22 20:28:22'),
(4, 1, 3, 4, 40, 36, 0, 5, 5, 0, '2025-09-22', NULL, '2025-09-22 20:28:22', '2025-09-22 20:28:22'),
(5, 2, 3, 5, 1, 36, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(6, 4, 3, 6, 14, 36, 0, 2, 2, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(7, 5, 3, 7, 25, 36, 0, 3, 3, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(8, 1, 3, 8, 40, 36, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(9, 2, 3, 9, 5, 9, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(10, 4, 3, 10, 19, 9, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(11, 5, 3, 11, 30, 9, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(12, 1, 3, 12, 41, 9, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(13, 2, 3, 13, 42, 11, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(14, 4, 3, 14, 22, 11, 0, 2, 2, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(15, 5, 3, 15, 33, 11, 0, 3, 3, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(16, 1, 3, 16, 43, 11, 0, 4, 4, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(17, 2, 3, 17, 44, 12, 0, 5, 5, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(18, 4, 3, 18, 23, 12, 0, 9, 9, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(19, 5, 3, 19, 34, 12, 0, 7, 7, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(20, 1, 3, 20, 45, 12, 0, 6, 6, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(21, 3, 2, 21, 36, 1, 0, 10, 10, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(22, 4, 2, 22, 14, 1, 0, 11, 11, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(23, 5, 2, 23, 25, 1, 0, 12, 12, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(24, 1, 2, 24, 40, 1, 0, 13, 13, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(25, 3, 2, 25, 38, 3, 0, 10, 10, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(26, 4, 2, 26, 17, 3, 0, 2, 2, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(27, 5, 2, 27, 28, 3, 0, 6, 6, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(28, 1, 2, 28, 46, 3, 0, 8, 8, 0, '2025-09-28', NULL, '2025-09-28 15:24:40', '2025-09-28 15:24:40'),
(29, 3, 2, 29, 10, 6, 0, 5, 5, 0, '2025-09-28', NULL, '2025-09-28 15:24:40', '2025-09-28 15:24:40'),
(30, 4, 2, 30, 20, 6, 0, 7, 7, 0, '2025-09-28', NULL, '2025-09-28 15:24:40', '2025-09-28 15:24:40'),
(31, 5, 2, 31, 31, 6, 0, 9, 9, 0, '2025-09-28', NULL, '2025-09-28 15:24:40', '2025-09-28 15:24:40'),
(32, 1, 2, 32, 47, 6, 0, 8, 8, 0, '2025-09-28', NULL, '2025-09-28 15:24:40', '2025-09-28 15:24:40'),
(33, 3, 2, 33, 12, 44, 0, 55, 55, 0, '2025-09-28', NULL, '2025-09-28 15:24:40', '2025-09-28 15:24:40'),
(34, 4, 2, 34, 23, 44, 0, 55, 55, 0, '2025-09-28', NULL, '2025-09-28 15:24:40', '2025-09-28 15:24:40'),
(35, 5, 2, 35, 34, 44, 0, 56, 56, 0, '2025-09-28', NULL, '2025-09-28 15:24:40', '2025-09-28 15:24:40'),
(36, 1, 2, 36, 45, 44, 0, 56, 56, 0, '2025-09-28', NULL, '2025-09-28 15:24:40', '2025-09-28 15:24:40');

-- --------------------------------------------------------

--
-- Table structure for table `stock_transfer_outs`
--

DROP TABLE IF EXISTS `stock_transfer_outs`;
CREATE TABLE IF NOT EXISTS `stock_transfer_outs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `store_id` bigint UNSIGNED NOT NULL,
  `to_store_id` bigint UNSIGNED NOT NULL,
  `stock_transfer_in_id` bigint DEFAULT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `to_store_product_id` bigint UNSIGNED NOT NULL,
  `box_qty` int DEFAULT '0',
  `loose_units` int DEFAULT NULL,
  `total_units` int DEFAULT NULL,
  `total_amount` bigint DEFAULT '0',
  `transfer_out_date` date DEFAULT NULL,
  `from_mobile_app` tinyint DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ToStoreProductIdIndex` (`to_store_product_id`),
  KEY `ProductIdStoreIdIndex` (`store_id`,`product_id`),
  KEY `store_id_transfer_out_date` (`store_id`,`transfer_out_date`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_transfer_outs`
--

INSERT INTO `stock_transfer_outs` (`id`, `store_id`, `to_store_id`, `stock_transfer_in_id`, `product_id`, `to_store_product_id`, `box_qty`, `loose_units`, `total_units`, `total_amount`, `transfer_out_date`, `from_mobile_app`, `created`, `modified`) VALUES
(1, 3, 2, NULL, 36, 1, 0, 2, 2, 0, '2025-09-22', NULL, '2025-09-22 20:28:22', '2025-09-22 20:28:22'),
(2, 3, 4, NULL, 36, 14, 0, 3, 3, 0, '2025-09-22', NULL, '2025-09-22 20:28:22', '2025-09-22 20:28:22'),
(3, 3, 5, NULL, 36, 25, 0, 4, 4, 0, '2025-09-22', NULL, '2025-09-22 20:28:22', '2025-09-22 20:28:22'),
(4, 3, 1, NULL, 36, 40, 0, 5, 5, 0, '2025-09-22', NULL, '2025-09-22 20:28:22', '2025-09-22 20:28:22'),
(5, 3, 2, NULL, 36, 1, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(6, 3, 4, NULL, 36, 14, 0, 2, 2, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(7, 3, 5, NULL, 36, 25, 0, 3, 3, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(8, 3, 1, NULL, 36, 40, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(9, 3, 2, NULL, 9, 5, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(10, 3, 4, NULL, 9, 19, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(11, 3, 5, NULL, 9, 30, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(12, 3, 1, NULL, 9, 41, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(13, 3, 2, NULL, 11, 42, 0, 1, 1, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(14, 3, 4, NULL, 11, 22, 0, 2, 2, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(15, 3, 5, NULL, 11, 33, 0, 3, 3, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(16, 3, 1, NULL, 11, 43, 0, 4, 4, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(17, 3, 2, NULL, 12, 44, 0, 5, 5, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(18, 3, 4, NULL, 12, 23, 0, 9, 9, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(19, 3, 5, NULL, 12, 34, 0, 7, 7, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(20, 3, 1, NULL, 12, 45, 0, 6, 6, 0, '2025-09-22', NULL, '2025-09-22 20:31:27', '2025-09-22 20:31:27'),
(21, 2, 3, NULL, 1, 36, 0, 10, 10, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(22, 2, 4, NULL, 1, 14, 0, 11, 11, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(23, 2, 5, NULL, 1, 25, 0, 12, 12, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(24, 2, 1, NULL, 1, 40, 0, 13, 13, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(25, 2, 3, NULL, 3, 38, 0, 10, 10, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(26, 2, 4, NULL, 3, 17, 0, 2, 2, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(27, 2, 5, NULL, 3, 28, 0, 6, 6, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(28, 2, 1, NULL, 3, 46, 0, 8, 8, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(29, 2, 3, NULL, 6, 10, 0, 5, 5, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(30, 2, 4, NULL, 6, 20, 0, 7, 7, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(31, 2, 5, NULL, 6, 31, 0, 9, 9, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(32, 2, 1, NULL, 6, 47, 0, 8, 8, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(33, 2, 3, NULL, 44, 12, 0, 55, 55, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(34, 2, 4, NULL, 44, 23, 0, 55, 55, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(35, 2, 5, NULL, 44, 34, 0, 56, 56, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39'),
(36, 2, 1, NULL, 44, 45, 0, 56, 56, 0, '2025-09-28', NULL, '2025-09-28 15:24:39', '2025-09-28 15:24:39');

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

DROP TABLE IF EXISTS `stores`;
CREATE TABLE IF NOT EXISTS `stores` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `active` tinyint DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `show_brands_in_products` tinyint DEFAULT '0',
  `show_brands_in_reports` tinyint DEFAULT '0',
  `print_header` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `print_footer` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `subscription_id` bigint UNSIGNED DEFAULT NULL,
  `subs_category` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subs_description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `subs_payment_type` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subs_payment_period` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subs_price` decimal(10,2) DEFAULT NULL,
  `subs_start_date` date DEFAULT NULL,
  `subs_end_date` date DEFAULT NULL,
  `subs_payable_amount` int DEFAULT NULL,
  `subs_remarks` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `state` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'TG',
  `group_id` bigint DEFAULT NULL,
  `retailer_code` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `license_no` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `beverage_invoice_upload` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`id`, `user_id`, `name`, `active`, `created`, `modified`, `expiry_date`, `show_brands_in_products`, `show_brands_in_reports`, `print_header`, `print_footer`, `subscription_id`, `subs_category`, `subs_description`, `subs_payment_type`, `subs_payment_period`, `subs_price`, `subs_start_date`, `subs_end_date`, `subs_payable_amount`, `subs_remarks`, `state`, `group_id`, `retailer_code`, `license_no`, `beverage_invoice_upload`) VALUES
(1, 1, 'Store-X', 1, '2025-09-08 20:55:00', '2025-09-08 20:55:00', '2025-10-08', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TG', 1, NULL, NULL, 0),
(2, 1, 'Store A', 1, '2025-09-08 20:55:54', '2025-09-08 20:57:47', '2026-10-08', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TG', 1, '', '', 0),
(3, 1, 'Store B', 1, '2025-09-08 20:56:15', '2025-09-08 20:56:15', '2026-10-08', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TG', 1, '', '', 0),
(4, 1, 'Store C', 1, '2025-09-08 20:56:21', '2025-09-08 20:56:21', '2025-10-08', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TG', 1, '', '', 0),
(5, 1, 'Store D', 1, '2025-09-08 20:59:13', '2025-09-08 20:59:13', '2025-10-08', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TG', 1, '', '', 0),
(6, 71, 'MB Liquor Mart Toopran', 1, '2025-09-17 12:58:09', '2025-09-17 13:04:38', '2025-10-17', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TG', 2, '', '', 0),
(7, 71, 'Brundavan - Narsapur', 1, '2025-09-17 13:01:58', '2025-09-17 13:01:58', '2025-10-17', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TG', 2, '', '', 0),
(8, 73, 'Gngwar', 1, '2025-09-27 21:03:17', '2025-09-27 21:04:43', '2025-12-31', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TG', 3, '', '', 0),
(9, 73, 'Nykl Belt', 1, '2025-09-27 21:04:07', '2025-09-27 21:04:07', '2025-11-30', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TG', 3, '', '', 0),
(10, 73, 'ZHB Gangwar', 1, '2025-11-09 09:49:37', '2025-11-09 09:53:25', '2026-11-30', 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TG', 4, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `store_passwords`
--

DROP TABLE IF EXISTS `store_passwords`;
CREATE TABLE IF NOT EXISTS `store_passwords` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `store_id` bigint UNSIGNED NOT NULL,
  `password` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `store_payments`
--

DROP TABLE IF EXISTS `store_payments`;
CREATE TABLE IF NOT EXISTS `store_payments` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `store_id` bigint UNSIGNED NOT NULL,
  `store_subscription_id` bigint UNSIGNED NOT NULL,
  `std_price` int DEFAULT NULL,
  `discount` int DEFAULT NULL,
  `payment_amount` decimal(12,2) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_status` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment_details` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `store_subscription_history`
--

DROP TABLE IF EXISTS `store_subscription_history`;
CREATE TABLE IF NOT EXISTS `store_subscription_history` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `active` tinyint DEFAULT '1',
  `store_id` bigint UNSIGNED NOT NULL,
  `subscription_id` bigint UNSIGNED NOT NULL,
  `subs_category` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subs_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `subs_payment_type` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subs_payment_period` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subs_price` decimal(12,2) DEFAULT NULL,
  `subs_start_date` date DEFAULT NULL,
  `subs_end_date` date DEFAULT NULL,
  `subs_payable_amount` decimal(12,2) DEFAULT NULL,
  `subs_remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `active` tinyint DEFAULT '1',
  `name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `category` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `payment_type` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment_period` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `price` int DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE IF NOT EXISTS `suppliers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `store_id` bigint UNSIGNED NOT NULL,
  `name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `store_id`, `name`, `email`, `phone`, `address`, `created`, `modified`) VALUES
(1, 37, 'Govt of Telangana Prohibition and Excise Department', '', '', 'Kompally, Survey No 726, Godowns of D.Laxmana reddy Shameerpet, Hyderabad', '2024-02-14 05:11:42', '2024-02-14 05:11:42');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `store_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `transaction_category_id` bigint UNSIGNED NOT NULL,
  `transaction_category_name` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_amount` decimal(12,2) DEFAULT NULL,
  `payment_type` enum('income','expense') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'expense',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `store_id` bigint UNSIGNED NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_category_id` (`transaction_category_id`),
  KEY `store_id_payment_type_payment_date` (`store_id`,`payment_type`,`payment_date`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `transaction_category_id`, `transaction_category_name`, `payment_date`, `payment_amount`, `payment_type`, `description`, `store_id`, `created`, `modified`) VALUES
(1, 1, 'Paytm', '2025-09-22', 50000.00, 'expense', '', 3, '2025-09-22 20:29:35', '2025-09-22 20:29:35'),
(2, 2, 'Cash in Bank', '2025-09-22', 60000.00, 'expense', '', 3, '2025-09-22 20:29:39', '2025-09-22 20:29:39'),
(3, 3, 'Paytm', '2025-09-28', 555000.00, 'expense', '', 5, '2025-09-28 15:26:30', '2025-09-28 15:26:30'),
(4, 4, 'Cash in Bank', '2025-09-28', 800000.00, 'expense', '', 2, '2025-09-28 15:27:28', '2025-09-28 15:27:28'),
(5, 4, 'Cash in Bank', '2025-10-11', 550000.00, 'expense', '', 2, '2025-10-11 14:51:30', '2025-10-11 14:51:30'),
(7, 6, 'Google Pay', '2025-10-06', 47810.00, 'expense', 'G Pay', 9, '2025-10-23 07:28:38', '2025-10-23 07:28:38'),
(8, 5, 'Net Cash', '2025-10-30', 123430.00, 'expense', 'Net cash', 9, '2025-11-10 07:13:57', '2025-11-10 07:13:57'),
(9, 6, 'Google Pay', '2025-10-30', 80380.00, 'expense', 'G Pay', 9, '2025-11-10 07:14:12', '2025-11-10 07:14:12'),
(10, 5, 'Net Cash', '2025-10-29', 131440.00, 'expense', 'Net cash', 9, '2025-11-10 07:17:08', '2025-11-10 07:17:08'),
(11, 6, 'Google Pay', '2025-10-29', 43100.00, 'expense', 'G Pay', 9, '2025-11-10 07:17:23', '2025-11-10 07:17:23'),
(12, 5, 'Net Cash', '2025-10-31', 14050.00, 'expense', 'Net cash', 9, '2025-11-10 07:37:43', '2025-11-10 07:37:43'),
(13, 5, 'Net Cash', '2025-10-31', 79180.00, 'expense', 'G Pay', 9, '2025-11-10 07:37:54', '2025-11-10 07:37:54'),
(14, 5, 'Net Cash', '2025-11-01', 239060.00, 'expense', 'Net cash', 9, '2025-11-10 07:57:26', '2025-11-10 07:57:26'),
(15, 6, 'Google Pay', '2025-11-01', 155560.00, 'expense', 'G Pay', 9, '2025-11-10 07:57:43', '2025-11-10 07:57:43');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_categories`
--

DROP TABLE IF EXISTS `transaction_categories`;
CREATE TABLE IF NOT EXISTS `transaction_categories` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '',
  `active` tinyint DEFAULT '1',
  `store_id` bigint UNSIGNED NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `show_in_balance_sheet` tinyint DEFAULT '0',
  `priority` int DEFAULT '0',
  `is_counter_sheet` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `active` (`active`),
  KEY `store_id` (`store_id`),
  KEY `is_counter_sheet` (`is_counter_sheet`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction_categories`
--

INSERT INTO `transaction_categories` (`id`, `name`, `active`, `store_id`, `created`, `modified`, `show_in_balance_sheet`, `priority`, `is_counter_sheet`) VALUES
(1, 'Paytm', 1, 3, '2025-09-22 20:29:17', '2025-09-22 20:29:17', 0, 0, 0),
(2, 'Cash in Bank', 1, 3, '2025-09-22 20:29:21', '2025-09-22 20:29:28', 1, 0, 1),
(3, 'Paytm', 1, 5, '2025-09-28 15:26:20', '2025-09-28 15:26:20', 0, 0, 0),
(4, 'Cash in Bank', 1, 2, '2025-09-28 15:27:22', '2025-09-28 15:27:22', 0, 0, 0),
(5, 'Net Cash', 1, 9, '2025-10-23 07:25:45', '2025-10-23 07:27:52', 0, 0, 0),
(6, 'Google Pay', 1, 9, '2025-10-23 07:25:56', '2025-10-23 07:25:56', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `transaction_logs`
--

DROP TABLE IF EXISTS `transaction_logs`;
CREATE TABLE IF NOT EXISTS `transaction_logs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `store_id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `payment_type` enum('expense','income') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'expense',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_date` date NOT NULL,
  `tag_id` bigint UNSIGNED NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `active` tinyint DEFAULT '1',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `feature_store_access_passwords` tinyint UNSIGNED NOT NULL DEFAULT '0',
  `store_password` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'master2020',
  `super_admin` tinyint DEFAULT '0',
  `is_admin` tinyint DEFAULT '0',
  `state` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'TG',
  `is_employee` tinyint DEFAULT '0',
  `role` enum('admin','employee') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'employee',
  `html_font_size` decimal(10,2) DEFAULT '0.85',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `active`, `name`, `email`, `password`, `created`, `modified`, `feature_store_access_passwords`, `store_password`, `super_admin`, `is_admin`, `state`, `is_employee`, `role`, `html_font_size`) VALUES
(1, 1, 'Preetham Pawar', 'preetham.pawar@gmail.com', '4967ab7ed7527c3381b8d561bbc90dcdcc591f11', '2013-03-14 08:53:20', '2025-09-07 19:19:33', 0, 'master2020', 1, 1, 'TG', 1, 'employee', 0.85),
(2, 1, 'Shankar Naik G', 'shankar.gskn@gmail.com', 'fbd3e8d76782bfe79ed8f09333586f764f7f4580', '2013-03-14 08:54:09', '2025-09-18 18:52:08', 1, 'master2020', 1, 1, 'TG', 1, 'employee', 0.83),
(69, 1, 'VT - Preetham Pawar', 'preetham.pawar@vishotech.com', '92ac8b932f22e55ed352b2af452388dcc465bf38', '2025-03-16 17:34:55', '2025-09-24 08:55:19', 1, '99999', 0, 0, 'TG', 1, 'employee', 0.85),
(70, 1, 'VT - Shankar G', 'shankar.g@vishotech.com', 'f4ab5b09f7b642769693cf2673cd794e4a98765f', '2025-03-16 17:35:29', '2025-05-25 19:46:52', 1, '99999', 0, 0, 'TG', 1, 'employee', 0.85),
(71, 1, 'VT - Vinod Naik', 'vinod.g@vishotech.com', '0b3ec80857660df5dc4f78e4904813cc755bc514', '2025-03-16 17:36:04', '2025-10-11 14:50:12', 1, '99999', 0, 1, 'TG', 1, 'employee', 0.89),
(73, 1, 'VT - Narashimha B', 'narasimha@vishotech.com', 'bd1a553e575f9e9991354e66054e5286ecd10046', '2025-03-17 02:37:07', '2025-10-23 08:07:06', 1, '99999', 0, 0, 'TG', 1, 'employee', 0.85),
(74, 1, 'Demo', 'demo.ts@gmail.com', '65782b50cfcd8839e21a3e7912fd4085081bf4ba', '2025-09-18 19:04:57', '2025-09-18 19:04:57', 1, '3040', 0, 1, 'TG', 0, 'employee', 0.85);

-- --------------------------------------------------------

--
-- Table structure for table `user_stores`
--

DROP TABLE IF EXISTS `user_stores`;
CREATE TABLE IF NOT EXISTS `user_stores` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `store_id` bigint UNSIGNED NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_stores`
--

INSERT INTO `user_stores` (`id`, `user_id`, `store_id`, `created`, `modified`) VALUES
(2, 74, 7, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(3, 74, 6, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(4, 74, 2, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(5, 71, 7, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(6, 71, 6, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(7, 71, 2, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(8, 71, 3, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(9, 71, 4, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(10, 71, 5, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(11, 69, 6, '2025-09-24 08:53:14', '2025-09-24 08:53:14'),
(12, 73, 8, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(13, 73, 9, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(14, 73, 10, '2025-11-09 09:50:19', '2025-11-09 09:50:19');

-- --------------------------------------------------------

--
-- Table structure for table `user_store_access`
--

DROP TABLE IF EXISTS `user_store_access`;
CREATE TABLE IF NOT EXISTS `user_store_access` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `store_id` bigint UNSIGNED NOT NULL,
  `module` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `view` tinyint DEFAULT '1',
  `add` tinyint DEFAULT '1',
  `edit` tinyint DEFAULT '1',
  `delete` tinyint DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=271 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_store_access`
--

INSERT INTO `user_store_access` (`id`, `user_id`, `store_id`, `module`, `view`, `add`, `edit`, `delete`, `created`, `modified`) VALUES
(16, 74, 7, 'group_products', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(17, 74, 7, 'group_dealers', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(18, 74, 7, 'group_brands', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(19, 74, 7, 'store_reports', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(20, 74, 7, 'products', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(21, 74, 7, 'invoices', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(22, 74, 7, 'purchases', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(23, 74, 7, 'sales', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(24, 74, 7, 'closing_stock', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(25, 74, 7, 'stock_transfer', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(26, 74, 7, 'cashbook', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(27, 74, 7, 'counter_sheet', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(28, 74, 7, 'transactions', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(29, 74, 7, 'bank_balance', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(30, 74, 7, 'reports', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(31, 74, 6, 'group_products', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(32, 74, 6, 'group_dealers', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(33, 74, 6, 'group_brands', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(34, 74, 6, 'store_reports', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(35, 74, 6, 'products', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(36, 74, 6, 'invoices', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(37, 74, 6, 'purchases', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(38, 74, 6, 'sales', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(39, 74, 6, 'closing_stock', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(40, 74, 6, 'stock_transfer', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(41, 74, 6, 'cashbook', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(42, 74, 6, 'counter_sheet', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(43, 74, 6, 'transactions', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(44, 74, 6, 'bank_balance', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(45, 74, 6, 'reports', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(46, 74, 2, 'group_products', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(47, 74, 2, 'group_dealers', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(48, 74, 2, 'group_brands', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(49, 74, 2, 'store_reports', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(50, 74, 2, 'products', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(51, 74, 2, 'invoices', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(52, 74, 2, 'purchases', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(53, 74, 2, 'sales', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(54, 74, 2, 'closing_stock', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(55, 74, 2, 'stock_transfer', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(56, 74, 2, 'cashbook', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(57, 74, 2, 'counter_sheet', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(58, 74, 2, 'transactions', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(59, 74, 2, 'bank_balance', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(60, 74, 2, 'reports', 1, 1, 1, 1, '2025-09-18 19:07:22', '2025-09-18 19:07:22'),
(61, 71, 7, 'group_products', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(62, 71, 7, 'group_dealers', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(63, 71, 7, 'group_brands', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(64, 71, 7, 'store_reports', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(65, 71, 7, 'products', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(66, 71, 7, 'invoices', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(67, 71, 7, 'purchases', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(68, 71, 7, 'sales', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(69, 71, 7, 'closing_stock', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(70, 71, 7, 'stock_transfer', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(71, 71, 7, 'cashbook', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(72, 71, 7, 'counter_sheet', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(73, 71, 7, 'transactions', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(74, 71, 7, 'bank_balance', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(75, 71, 7, 'reports', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(76, 71, 6, 'group_products', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(77, 71, 6, 'group_dealers', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(78, 71, 6, 'group_brands', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(79, 71, 6, 'store_reports', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(80, 71, 6, 'products', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(81, 71, 6, 'invoices', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(82, 71, 6, 'purchases', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(83, 71, 6, 'sales', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(84, 71, 6, 'closing_stock', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(85, 71, 6, 'stock_transfer', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(86, 71, 6, 'cashbook', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(87, 71, 6, 'counter_sheet', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(88, 71, 6, 'transactions', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(89, 71, 6, 'bank_balance', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(90, 71, 6, 'reports', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(106, 71, 3, 'group_products', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(107, 71, 3, 'group_dealers', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(108, 71, 3, 'group_brands', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(109, 71, 3, 'store_reports', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(110, 71, 3, 'products', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(111, 71, 3, 'invoices', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(112, 71, 3, 'purchases', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(113, 71, 3, 'sales', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(114, 71, 3, 'closing_stock', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(115, 71, 3, 'stock_transfer', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(116, 71, 3, 'cashbook', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(117, 71, 3, 'counter_sheet', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(118, 71, 3, 'transactions', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(119, 71, 3, 'bank_balance', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(120, 71, 3, 'reports', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(121, 71, 4, 'group_products', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(122, 71, 4, 'group_dealers', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(123, 71, 4, 'group_brands', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(124, 71, 4, 'store_reports', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(125, 71, 4, 'products', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(126, 71, 4, 'invoices', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(127, 71, 4, 'purchases', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(128, 71, 4, 'sales', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(129, 71, 4, 'closing_stock', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(130, 71, 4, 'stock_transfer', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(131, 71, 4, 'cashbook', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(132, 71, 4, 'counter_sheet', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(133, 71, 4, 'transactions', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(134, 71, 4, 'bank_balance', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(135, 71, 4, 'reports', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(136, 71, 5, 'group_products', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(137, 71, 5, 'group_dealers', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(138, 71, 5, 'group_brands', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(139, 71, 5, 'store_reports', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(140, 71, 5, 'products', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(141, 71, 5, 'invoices', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(142, 71, 5, 'purchases', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(143, 71, 5, 'sales', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(144, 71, 5, 'closing_stock', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(145, 71, 5, 'stock_transfer', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(146, 71, 5, 'cashbook', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(147, 71, 5, 'counter_sheet', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(148, 71, 5, 'transactions', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(149, 71, 5, 'bank_balance', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(150, 71, 5, 'reports', 1, 1, 1, 1, '2025-09-21 18:37:12', '2025-09-21 18:37:12'),
(151, 71, 2, 'group_products', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(152, 71, 2, 'group_dealers', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(153, 71, 2, 'group_brands', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(154, 71, 2, 'store_reports', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(155, 71, 2, 'products', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(156, 71, 2, 'invoices', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(157, 71, 2, 'purchases', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(158, 71, 2, 'sales', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(159, 71, 2, 'closing_stock', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(160, 71, 2, 'stock_transfer', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(161, 71, 2, 'cashbook', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(162, 71, 2, 'counter_sheet', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(163, 71, 2, 'transactions', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(164, 71, 2, 'bank_balance', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(165, 71, 2, 'reports', 1, 1, 1, 1, '2025-09-23 11:04:29', '2025-09-23 11:04:29'),
(181, 69, 6, 'group_products', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(182, 69, 6, 'group_dealers', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(183, 69, 6, 'group_brands', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(184, 69, 6, 'store_reports', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(185, 69, 6, 'products', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(186, 69, 6, 'invoices', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(187, 69, 6, 'purchases', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(188, 69, 6, 'sales', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(189, 69, 6, 'closing_stock', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(190, 69, 6, 'stock_transfer', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(191, 69, 6, 'cashbook', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(192, 69, 6, 'counter_sheet', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(193, 69, 6, 'transactions', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(194, 69, 6, 'bank_balance', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(195, 69, 6, 'reports', 1, 1, 1, 1, '2025-09-24 08:54:23', '2025-09-24 08:54:23'),
(211, 73, 9, 'group_products', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(212, 73, 9, 'group_dealers', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(213, 73, 9, 'group_brands', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(214, 73, 9, 'store_reports', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(215, 73, 9, 'products', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(216, 73, 9, 'invoices', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(217, 73, 9, 'purchases', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(218, 73, 9, 'sales', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(219, 73, 9, 'closing_stock', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(220, 73, 9, 'stock_transfer', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(221, 73, 9, 'cashbook', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(222, 73, 9, 'counter_sheet', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(223, 73, 9, 'transactions', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(224, 73, 9, 'bank_balance', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(225, 73, 9, 'reports', 1, 1, 1, 1, '2025-10-16 19:31:12', '2025-10-16 19:31:12'),
(226, 73, 8, 'group_products', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(227, 73, 8, 'group_dealers', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(228, 73, 8, 'group_brands', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(229, 73, 8, 'store_reports', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(230, 73, 8, 'products', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(231, 73, 8, 'invoices', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(232, 73, 8, 'purchases', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(233, 73, 8, 'sales', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(234, 73, 8, 'closing_stock', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(235, 73, 8, 'stock_transfer', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(236, 73, 8, 'cashbook', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(237, 73, 8, 'counter_sheet', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(238, 73, 8, 'transactions', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(239, 73, 8, 'bank_balance', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(240, 73, 8, 'reports', 1, 1, 1, 1, '2025-11-09 09:45:42', '2025-11-09 09:45:42'),
(256, 73, 10, 'group_products', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(257, 73, 10, 'group_dealers', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(258, 73, 10, 'group_brands', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(259, 73, 10, 'store_reports', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(260, 73, 10, 'products', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(261, 73, 10, 'invoices', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(262, 73, 10, 'purchases', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(263, 73, 10, 'sales', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(264, 73, 10, 'closing_stock', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(265, 73, 10, 'stock_transfer', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(266, 73, 10, 'cashbook', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(267, 73, 10, 'counter_sheet', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(268, 73, 10, 'transactions', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(269, 73, 10, 'bank_balance', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39'),
(270, 73, 10, 'reports', 1, 1, 1, 1, '2025-11-09 09:54:39', '2025-11-09 09:54:39');

-- --------------------------------------------------------

--
-- Structure for view `product_breakage_report`
--
DROP TABLE IF EXISTS `product_breakage_report`;

DROP VIEW IF EXISTS `product_breakage_report`;
CREATE OR REPLACE VIEW `product_breakage_report`  AS SELECT `pr`.`id` AS `id`, `pr`.`name` AS `product_name`, `pr`.`product_category_id` AS `product_category_id`, `pr`.`store_id` AS `store_id`, coalesce(sum(`b`.`total_units`),0) AS `breakage_qty`, coalesce(sum(`b`.`total_amount`),0) AS `breakage_amount` FROM (`products` `pr` left join `breakages` `b` on((`pr`.`id` = `b`.`product_id`))) GROUP BY `pr`.`id` ;

-- --------------------------------------------------------

--
-- Structure for view `product_purchase_report`
--
DROP TABLE IF EXISTS `product_purchase_report`;

DROP VIEW IF EXISTS `product_purchase_report`;
CREATE OR REPLACE VIEW `product_purchase_report`  AS SELECT `pr`.`id` AS `id`, `pr`.`name` AS `product_name`, `pr`.`product_category_id` AS `product_category_id`, `pr`.`store_id` AS `store_id`, coalesce(sum(`pu`.`total_units`),0) AS `purchase_qty`, coalesce(sum(`pu`.`total_amount`),0) AS `purchase_amount` FROM (`products` `pr` left join `purchases` `pu` on((`pr`.`id` = `pu`.`product_id`))) GROUP BY `pr`.`id` ;

-- --------------------------------------------------------

--
-- Structure for view `product_sale_report`
--
DROP TABLE IF EXISTS `product_sale_report`;

DROP VIEW IF EXISTS `product_sale_report`;
CREATE OR REPLACE VIEW `product_sale_report`  AS SELECT `pr`.`id` AS `id`, `pr`.`name` AS `product_name`, `pr`.`product_category_id` AS `product_category_id`, `pr`.`store_id` AS `store_id`, coalesce(sum(`s`.`total_units`),0) AS `sale_qty`, coalesce(sum(`s`.`total_amount`),0) AS `sale_amount` FROM (`products` `pr` left join `sales` `s` on((`pr`.`id` = `s`.`product_id`))) GROUP BY `pr`.`id` ;

-- --------------------------------------------------------

--
-- Structure for view `product_stock_report`
--
DROP TABLE IF EXISTS `product_stock_report`;

DROP VIEW IF EXISTS `product_stock_report`;
CREATE OR REPLACE VIEW `product_stock_report`  AS SELECT `p`.`id` AS `product_id`, `p`.`product_name` AS `product_name`, `c`.`id` AS `category_id`, `c`.`name` AS `category_name`, `p`.`store_id` AS `store_id`, coalesce(`p`.`purchase_qty`,0) AS `purchase_qty`, coalesce(`p`.`purchase_amount`,0) AS `purchase_amount`, coalesce(`s`.`sale_qty`,0) AS `sale_qty`, coalesce(`s`.`sale_amount`,0) AS `sale_amount`, coalesce(`b`.`breakage_qty`,0) AS `breakage_qty`, coalesce(`b`.`breakage_amount`,0) AS `breakage_amount`, coalesce(`sto`.`stock_transfer_out_qty`,0) AS `stock_transfer_out_qty`, coalesce(`sto`.`total_amount`,0) AS `stock_transfer_out_amount`, coalesce(`sti`.`stock_transfer_in_qty`,0) AS `stock_transfer_in_qty`, coalesce(`sti`.`total_amount`,0) AS `stock_transfer_in_amount`, ((((coalesce(`p`.`purchase_qty`,0) + coalesce(`sti`.`stock_transfer_in_qty`,0)) - coalesce(`s`.`sale_qty`,0)) - coalesce(`b`.`breakage_qty`,0)) - coalesce(`sto`.`stock_transfer_out_qty`,0)) AS `balance_qty`, ((((coalesce(`s`.`sale_amount`,0) + coalesce(`sto`.`total_amount`,0)) - coalesce(`p`.`purchase_amount`,0)) - coalesce(`b`.`breakage_qty`,0)) - coalesce(`sti`.`total_amount`,0)) AS `profit_amount` FROM (((((`product_purchase_report` `p` left join `product_sale_report` `s` on((`s`.`id` = `p`.`id`))) left join `product_breakage_report` `b` on((`b`.`id` = `p`.`id`))) left join `product_stock_transfer_in_report` `sti` on((`sti`.`id` = `p`.`id`))) left join `product_stock_transfer_out_report` `sto` on((`sto`.`id` = `p`.`id`))) left join `product_categories` `c` on((`c`.`id` = `p`.`product_category_id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `product_stock_transfer_in_report`
--
DROP TABLE IF EXISTS `product_stock_transfer_in_report`;

DROP VIEW IF EXISTS `product_stock_transfer_in_report`;
CREATE OR REPLACE VIEW `product_stock_transfer_in_report`  AS SELECT `pr`.`id` AS `id`, `pr`.`name` AS `product_name`, `pr`.`product_category_id` AS `product_category_id`, `pr`.`store_id` AS `store_id`, coalesce(sum(`s`.`total_units`),0) AS `stock_transfer_in_qty`, coalesce(sum(`s`.`total_amount`),0) AS `total_amount` FROM (`products` `pr` left join `stock_transfer_ins` `s` on((`pr`.`id` = `s`.`product_id`))) GROUP BY `pr`.`id` ;

-- --------------------------------------------------------

--
-- Structure for view `product_stock_transfer_out_report`
--
DROP TABLE IF EXISTS `product_stock_transfer_out_report`;

DROP VIEW IF EXISTS `product_stock_transfer_out_report`;
CREATE OR REPLACE VIEW `product_stock_transfer_out_report`  AS SELECT `pr`.`id` AS `id`, `pr`.`name` AS `product_name`, `pr`.`product_category_id` AS `product_category_id`, `pr`.`store_id` AS `store_id`, coalesce(sum(`s`.`total_units`),0) AS `stock_transfer_out_qty`, coalesce(sum(`s`.`total_amount`),0) AS `total_amount` FROM (`products` `pr` left join `stock_transfer_outs` `s` on((`pr`.`id` = `s`.`product_id`))) GROUP BY `pr`.`id` ;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
